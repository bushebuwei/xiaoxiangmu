package com.project.client.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
@RestController
@RequestMapping("/farmInformation")
public class FarmInformationController {

}
