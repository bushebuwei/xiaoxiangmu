package com.project.client.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.model.SettlementInvite;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.HashMap;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lemon
 * @since 2025-04-05
 */
public interface SettlementInviteService extends IService<SettlementInvite> {

    Page<SettlementInvite> getSettlementInvite(HashMap searchMap);
}
