package com.project.client.controller;

import com.project.client.service.SysAuthorityRolePermissionService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sysAuthorityRolePermission")
public class SysAuthorityRolePermissionController {
    private final SysAuthorityRolePermissionService sysAuthorityRolePermissionService;

    public SysAuthorityRolePermissionController(SysAuthorityRolePermissionService sysAuthorityRolePermissionService) {
        this.sysAuthorityRolePermissionService = sysAuthorityRolePermissionService;
    }

    @RequestMapping("/getRoleAndPermission")
    public RespResult getRoleAndPermission() {
        return sysAuthorityRolePermissionService.getRoleAndPermission();
    }
}
