package com.project.client.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.client.dto.CustInfoSearchDto;
import com.project.client.dto.LoginDto;
import com.project.client.model.CustInformation;
import com.project.util.RespResult;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface CustInformationService extends IService<CustInformation> {

    CustInformation login(LoginDto loginDto);

    Page<CustInformation> getCustUsers(HashMap searchMap);

    List<Map<String, String>> getCustNames();
}
