package com.project.client.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.client.model.OrderDetail;
import com.project.client.service.OrderDetailService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author lemon
 * @since 2025-03-11
 */
@RestController
@RequestMapping("/orderDetail")
public class OrderDetailController {
    private final OrderDetailService orderDetailService;

    public OrderDetailController(OrderDetailService orderDetailService) {
        this.orderDetailService = orderDetailService;
    }

    @RequestMapping("/getOrderDetailByOrderId")
    public RespResult getOrderDetailByOrderId(String orderId) {
        QueryWrapper<OrderDetail> wrapper = new QueryWrapper<>();
        wrapper.eq("order_id", orderId);
        return RespResult.ok(orderDetailService.getOne(wrapper));
    }
}
