package com.project.client.service;

import com.project.client.model.SysAuthorityPermission;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.util.RespResult;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
public interface SysAuthorityPermissionService extends IService<SysAuthorityPermission> {

    RespResult getPermissionByRoleId(String roleId);
}
