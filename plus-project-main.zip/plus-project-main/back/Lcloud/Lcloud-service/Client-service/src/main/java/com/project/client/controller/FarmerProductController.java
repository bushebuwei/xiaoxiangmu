package com.project.client.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.model.FarmerInformation;
import com.project.client.model.FarmerProduct;
import com.project.client.service.FarmerProductService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
@RestController
@RequestMapping("/farmerProduct")
public class FarmerProductController {
    private final FarmerProductService farmerProductService;

    public FarmerProductController(FarmerProductService farmerProductService) {
        this.farmerProductService = farmerProductService;
    }

    @RequestMapping("/addProduct")
    public RespResult addProduct(@RequestBody FarmerProduct farmerProduct) {
        return RespResult.ok(farmerProductService.save(farmerProduct));
    }

    @RequestMapping("/getFarmerProducts")
    public RespResult<Page<FarmerProduct>> getFarmerProducts(@RequestBody HashMap searchMap) {
        Page<FarmerProduct> farmerProductPage = farmerProductService.getFarmerInformations(searchMap);
        return RespResult.ok(farmerProductPage);
    }

    @RequestMapping("/getFarmerProductNames")
    public RespResult getFarmerProductNames() {
        List<Map<String, String>> resultList = farmerProductService.getFarmerProductNames();
        return RespResult.ok(resultList);
    }
}
