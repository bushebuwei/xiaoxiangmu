package com.project.client.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.dto.LoginDto;
import com.project.client.dto.SysUserDto;
import com.project.client.model.SysAuthorityUserRole;
import com.project.client.model.SysUser;
import com.project.client.model.UserAccount;
import com.project.client.service.SysAuthorityUserRoleService;
import com.project.client.service.SysUserService;
import com.project.client.service.UserAccountService;
import com.project.util.RespResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;


@RestController
@RequestMapping("/user")
public class SysUserController {
    private final SysUserService sysUserService;

    private final SysAuthorityUserRoleService sysAuthorityUserRoleService;

    private final UserAccountService userAccountService;

    public SysUserController(SysUserService sysUserService,
                             SysAuthorityUserRoleService sysAuthorityUserRoleService,
                             UserAccountService userAccountService) {
        this.sysUserService = sysUserService;
        this.sysAuthorityUserRoleService = sysAuthorityUserRoleService;
        this.userAccountService = userAccountService;
    }

    @PostMapping("/login")
    public RespResult login(@RequestBody LoginDto loginDto) {
        return sysUserService.login(loginDto);
    }

    @RequestMapping("/getUsers")
    public RespResult<Page<SysUser>> getUsers(@RequestBody HashMap searchMap) {
        Page<SysUser> sysUserPage = sysUserService.getUsers(searchMap);
        return RespResult.ok(sysUserPage);
    }

    @RequestMapping("/addUser")
    @Transactional
    public RespResult addUser(@RequestBody SysUserDto sysUserDto) {
        SysUser sysUser = sysUserDto.getSysUser();
        List<String> roleIdList = sysUserDto.getRoleIds();
        sysUser.setCreateDate(new Date());
        sysUser.setCurrentCount(0);
        sysUser.setStatus("1");
        sysUserService.save(sysUser);
        String roleIds = String.join(",", roleIdList);
        SysAuthorityUserRole userRole = new SysAuthorityUserRole();
        userRole.setRoleIds(roleIds);
        userRole.setUserId(sysUser.getId());
        userRole.setCreateDate(new Date());
        userRole.setUserType("1");
        userRole.setStatus("1");
        sysAuthorityUserRoleService.save(userRole);
        UserAccount userAccount = new UserAccount();
        userAccount.setAccount(sysUser.getUserName());
        userAccount.setType("1");
        userAccountService.save(userAccount);
        return RespResult.ok("添加角色成功");
    }

    @RequestMapping("/editUser")
    @Transactional
    public RespResult editUser(@RequestBody SysUserDto sysUserDto) {
        SysUser sysUser = sysUserDto.getSysUser();
        sysUserService.updateById(sysUser);
        String roleIds = String.join(",", sysUserDto.getRoleIds());
        QueryWrapper<SysAuthorityUserRole> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", sysUser.getId());
        SysAuthorityUserRole updateUserRole = new SysAuthorityUserRole();
        updateUserRole.setRoleIds(roleIds);
        sysAuthorityUserRoleService.update(updateUserRole, wrapper);
        return RespResult.ok("修改成功");
    }

    @RequestMapping("/deleteUserById/{id}")
    public RespResult deleteUserById(@PathVariable String id) {
        return RespResult.ok(sysUserService.deleteById(id));
    }
}
