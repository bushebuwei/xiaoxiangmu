package com.project.client.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.model.OrderDetail;
import com.project.client.model.SettlementInvite;
import com.project.client.model.SysUser;
import com.project.client.service.SettlementInviteService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author lemon
 * @since 2025-04-05
 */
@RestController
@RequestMapping("/settlementInvite")
public class SettlementInviteController {
    private final SettlementInviteService settlementInviteService;

    public SettlementInviteController(SettlementInviteService settlementInviteService) {
        this.settlementInviteService = settlementInviteService;
    }

    @RequestMapping("/startSettlement")
    public RespResult startSettlement(@RequestBody SettlementInvite settlementInvite) {
        settlementInvite.setInviteTime(new Date());
        settlementInviteService.save(settlementInvite);
        return RespResult.ok();
    }

    @RequestMapping("/getSettlementInvites")
    public RespResult<Page<SettlementInvite>> getSettlementInvites(@RequestBody HashMap searchMap) {
        Page<SettlementInvite> settlementInvitePage = settlementInviteService.getSettlementInvite(searchMap);
        return RespResult.ok(settlementInvitePage);
    }
}
