package com.project.client.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.model.CustInformation;
import com.project.client.model.FarmerInformation;
import com.project.client.model.FarmerProduct;
import com.project.client.mapper.FarmerProductMapper;
import com.project.client.service.FarmerProductService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
@Service
public class FarmerProductServiceImpl extends ServiceImpl<FarmerProductMapper, FarmerProduct> implements FarmerProductService {

    @Override
    public Page<FarmerProduct> getFarmerInformations(HashMap searchMap) {
        String productName = (String) searchMap.getOrDefault("product_name", "");
        String createDateStr = (String) searchMap.get("createDate");
        boolean createDateStrNotNull = createDateStr != null && !createDateStr.equals("");
        if (createDateStrNotNull) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-M-d");
                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-M-d HH:mm:ss");
                Date parse = inputFormat.parse(createDateStr);
                createDateStr = outputFormat.format(parse);
            } catch (Exception e) {
                throw new RuntimeException("日期格式错误");
            }
        }
        QueryWrapper<FarmerProduct> wrapper = new QueryWrapper<>();
        wrapper.like("product_name", productName);
        wrapper.gt(createDateStrNotNull, "create_date", createDateStr);
        wrapper.eq("status", "1");
        int page = (int) searchMap.getOrDefault("page", "1");
        int pageSize = (int) searchMap.getOrDefault("pageSize", "10");
        Page<FarmerProduct> pages = new Page<>(page, pageSize);
        return this.page(pages, wrapper);
    }

    @Override
    public List<Map<String, String>> getFarmerProductNames() {
        List<FarmerProduct> farmerProducts = this.list();
        return farmerProducts.stream().map(farmerProduct -> {
            Map<String, String> map = new HashMap<>();
            map.put("farmerProductId", farmerProduct.getId());
            map.put("name", farmerProduct.getProductName());
            return map;
        }).collect(Collectors.toList());
    }
}
