package com.project.client.service.impl;

import com.project.client.model.SysAuthorityUserRole;
import com.project.client.mapper.SysAuthorityUserRoleMapper;
import com.project.client.service.SysAuthorityUserRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
@Service
public class SysAuthorityUserRoleServiceImpl extends ServiceImpl<SysAuthorityUserRoleMapper, SysAuthorityUserRole> implements SysAuthorityUserRoleService {

}
