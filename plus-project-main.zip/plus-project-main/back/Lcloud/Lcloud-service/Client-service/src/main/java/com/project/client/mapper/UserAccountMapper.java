package com.project.client.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.project.client.model.UserAccount;

public interface UserAccountMapper extends BaseMapper<UserAccount> {
}
