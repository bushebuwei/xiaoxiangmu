package com.project.client.controller;

import com.project.client.model.SysAuthorityUserRole;
import com.project.client.service.SysAuthorityUserRoleService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/sysAuthorityUserRole")
public class SysAuthorityUserRoleController {
    private final SysAuthorityUserRoleService sysAuthorityUserRoleService;

    public SysAuthorityUserRoleController(SysAuthorityUserRoleService sysAuthorityUserRoleService) {
        this.sysAuthorityUserRoleService = sysAuthorityUserRoleService;
    }

    @RequestMapping("/getUserRoles")
    public RespResult<List<SysAuthorityUserRole>> getUserRoles() {
        return RespResult.ok(sysAuthorityUserRoleService.list());
    }
}
