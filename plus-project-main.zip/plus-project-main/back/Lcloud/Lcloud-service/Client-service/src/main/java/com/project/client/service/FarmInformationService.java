package com.project.client.service;

import com.project.client.model.FarmInformation;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
public interface FarmInformationService extends IService<FarmInformation> {

}
