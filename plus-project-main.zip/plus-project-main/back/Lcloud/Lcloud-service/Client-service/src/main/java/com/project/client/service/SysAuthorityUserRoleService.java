package com.project.client.service;

import com.project.client.model.SysAuthorityUserRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
public interface SysAuthorityUserRoleService extends IService<SysAuthorityUserRole> {

}
