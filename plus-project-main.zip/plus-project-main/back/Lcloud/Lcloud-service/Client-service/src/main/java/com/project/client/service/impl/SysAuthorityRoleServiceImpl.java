package com.project.client.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.client.dto.SysAuthorityUserDto;
import com.project.client.model.SysAuthorityPermission;
import com.project.client.model.SysAuthorityRole;
import com.project.client.mapper.SysAuthorityRoleMapper;
import com.project.client.model.SysAuthorityRolePermission;
import com.project.client.service.SysAuthorityPermissionService;
import com.project.client.service.SysAuthorityRolePermissionService;
import com.project.client.service.SysAuthorityRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.util.RespResult;
import org.apache.commons.lang.text.StrBuilder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
@Service
public class SysAuthorityRoleServiceImpl extends ServiceImpl<SysAuthorityRoleMapper, SysAuthorityRole> implements SysAuthorityRoleService {

    private final SysAuthorityPermissionService sysAuthorityPermissionService;

    private final SysAuthorityRolePermissionService sysAuthorityRolePermissionService;

    public SysAuthorityRoleServiceImpl(SysAuthorityPermissionService sysAuthorityPermissionService,
                                       SysAuthorityRolePermissionService sysAuthorityRolePermissionService) {
        this.sysAuthorityPermissionService = sysAuthorityPermissionService;
        this.sysAuthorityRolePermissionService = sysAuthorityRolePermissionService;
    }

    @Override
    public RespResult addRole(SysAuthorityUserDto sysAuthorityUserDto) {
        String roleName = sysAuthorityUserDto.getRoleName();
        String roleValue = sysAuthorityUserDto.getRoleValue();
        List<String> permissions = sysAuthorityUserDto.getPermissions();
        SysAuthorityRole sysAuthorityRole = new SysAuthorityRole();
        sysAuthorityRole.setRoleName(roleName);
        sysAuthorityRole.setRoleValue(roleValue);
        this.save(sysAuthorityRole);
        QueryWrapper<SysAuthorityPermission> wrapper = new QueryWrapper<>();
        wrapper.in("perm_value", permissions);
        List<SysAuthorityPermission> sysAuthorityPermissions = sysAuthorityPermissionService.list(wrapper);

        List<String> permIds = sysAuthorityPermissions.stream()
                .map(SysAuthorityPermission::getPermId)
                .collect(Collectors.toList());

        String roleIds = String.join(",", permIds);

        SysAuthorityRolePermission sysAuthorityRolePermission = new SysAuthorityRolePermission();
        String roleId = sysAuthorityRole.getRoleId();
        sysAuthorityRolePermission.setRoleId(roleId);
        sysAuthorityRolePermission.setPermIds(roleIds);
        sysAuthorityRolePermission.setStatus("1");

        sysAuthorityRolePermissionService.save(sysAuthorityRolePermission);
        return RespResult.ok();
    }
}
