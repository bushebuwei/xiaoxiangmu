package com.project;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@SpringBootApplication
@MapperScan(basePackages = {"com.project.client.mapper"})
@EnableTransactionManagement
public class LcloudClientApplication {
    public static void main(String[] args) {
        SpringApplication.run(LcloudClientApplication.class, args);
    }
}
