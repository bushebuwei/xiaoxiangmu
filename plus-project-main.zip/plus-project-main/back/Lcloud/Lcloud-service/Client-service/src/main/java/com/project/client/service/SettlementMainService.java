package com.project.client.service;

import com.project.client.model.SettlementMain;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lemon
 * @since 2025-04-05
 */
public interface SettlementMainService extends IService<SettlementMain> {

}
