package com.project.client.mapper;

import com.project.client.model.FarmInformation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
public interface FarmInformationMapper extends BaseMapper<FarmInformation> {

}

