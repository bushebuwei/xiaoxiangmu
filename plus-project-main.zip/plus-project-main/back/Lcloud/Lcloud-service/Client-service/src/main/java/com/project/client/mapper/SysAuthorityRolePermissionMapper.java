package com.project.client.mapper;

import com.project.client.model.SysAuthorityRolePermission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
public interface SysAuthorityRolePermissionMapper extends BaseMapper<SysAuthorityRolePermission> {

}

