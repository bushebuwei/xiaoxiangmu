package com.project.client.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.client.mapper.UserAccountMapper;
import com.project.client.model.UserAccount;
import com.project.client.service.UserAccountService;
import org.springframework.stereotype.Service;

@Service
public class UserAccountServiceImpl extends ServiceImpl<UserAccountMapper, UserAccount> implements UserAccountService {
}
