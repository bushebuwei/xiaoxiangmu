package com.project.client.mapper;

import com.project.client.model.SysAuthorityUserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
public interface SysAuthorityUserRoleMapper extends BaseMapper<SysAuthorityUserRole> {

}

