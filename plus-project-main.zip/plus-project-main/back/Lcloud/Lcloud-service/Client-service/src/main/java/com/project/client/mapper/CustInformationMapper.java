package com.project.client.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.project.client.dto.LoginDto;
import com.project.client.model.CustInformation;
import com.project.util.RespResult;

public interface CustInformationMapper extends BaseMapper<CustInformation> {
}
