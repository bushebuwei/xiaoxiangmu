package com.project.client.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.dto.CustInfoSearchDto;
import com.project.client.model.CustInformation;
import com.project.client.service.CustInformationService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/custInformation")
public class CustInformationController {
    private final CustInformationService custInformationService;

    public CustInformationController(CustInformationService custInformationService) {
        this.custInformationService = custInformationService;
    }

    @RequestMapping("/addCust")
    public RespResult addCustInformation(@RequestBody CustInformation custInformation) {
        custInformationService.save(custInformation);
        return RespResult.ok("新增客户成功");
    }

    @RequestMapping("/delete/{id}")
    public RespResult deleteCustInformation(@PathVariable String id) {
        custInformationService.removeById(id);
        return RespResult.ok("删除客户成功");
    }

    @RequestMapping("/update")
    public RespResult updateCustInformation(@RequestBody CustInformation custInformation) {
        custInformationService.updateById(custInformation);
        return RespResult.ok("更新客户成功");
    }


    @RequestMapping("getCustUsers")
    public RespResult<Page<CustInformation>> getCustUsers(@RequestBody HashMap searchMap) {
        Page<CustInformation> custInformationPage = custInformationService.getCustUsers(searchMap);
        return RespResult.ok(custInformationPage);
    }

    @RequestMapping("/getCustNames")
    public RespResult getCustNames() {
        List<Map<String, String>> resultList = custInformationService.getCustNames();
        return RespResult.ok(resultList);
    }
}
