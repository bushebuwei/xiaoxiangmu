package com.project.client.mapper;

import com.project.client.model.OrderHead;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lemon
 * @since 2025-03-11
 */
public interface OrderHeadMapper extends BaseMapper<OrderHead> {

}

