package com.project.client.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.model.OrderHead;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.util.RespResult;

import java.util.HashMap;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author lemon
 * @since 2025-03-11
 */
public interface OrderHeadService extends IService<OrderHead> {

    Page<OrderHead> getOrderHeads(HashMap searchMap);

    RespResult addOrder(HashMap<String, String> orderMap);
}
