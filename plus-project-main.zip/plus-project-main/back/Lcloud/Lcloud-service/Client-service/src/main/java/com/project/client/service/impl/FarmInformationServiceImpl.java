package com.project.client.service.impl;

import com.project.client.model.FarmInformation;
import com.project.client.mapper.FarmInformationMapper;
import com.project.client.service.FarmInformationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
@Service
public class FarmInformationServiceImpl extends ServiceImpl<FarmInformationMapper, FarmInformation> implements FarmInformationService {

}
