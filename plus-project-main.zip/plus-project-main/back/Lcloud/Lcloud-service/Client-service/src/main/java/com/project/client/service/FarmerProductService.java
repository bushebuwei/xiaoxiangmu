package com.project.client.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.model.FarmerProduct;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
public interface FarmerProductService extends IService<FarmerProduct> {

    Page<FarmerProduct> getFarmerInformations(HashMap searchMap);

    List<Map<String, String>> getFarmerProductNames();
}
