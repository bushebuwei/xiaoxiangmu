package com.project.client.mapper;

import com.project.client.model.FarmerInformation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.project.client.model.FarmerInformation;


/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author cust
 * @since 2025-03-06
 */
public interface FarmerInformationMapper extends BaseMapper<FarmerInformation> {

}

