package com.project.client.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.client.dto.LoginDto;
import com.project.client.mapper.*;
import com.project.client.model.*;
import com.project.client.myEnum.RoleTypeEnum;
import com.project.client.service.CustInformationService;
import com.project.client.service.FarmerInformationService;
import com.project.client.service.SysUserService;
import com.project.util.RespResult;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements SysUserService {

    private final SysUserMapper sysUserMapper;
    private final SysAuthorityUserRoleMapper sysAuthorityUserRoleMapper;
    private final SysAuthorityRoleMapper sysAuthorityRoleMapper;

    private final CustInformationService custInformationService;

    private final FarmerInformationService farmerInformationService;
    private final UserAccountMapper userAccountMapper;

    public SysUserServiceImpl(SysUserMapper sysUserMapper,
                              SysAuthorityUserRoleMapper sysAuthorityUserRoleMapper,
                              SysAuthorityRoleMapper sysAuthorityRoleMapper,
                              CustInformationService custInformationService,
                              FarmerInformationService farmerInformationService,
                              UserAccountMapper userAccountMapper) {
        this.sysUserMapper = sysUserMapper;
        this.sysAuthorityUserRoleMapper = sysAuthorityUserRoleMapper;
        this.sysAuthorityRoleMapper = sysAuthorityRoleMapper;
        this.farmerInformationService = farmerInformationService;
        this.userAccountMapper = userAccountMapper;
        this.custInformationService = custInformationService;
    }

    @Override
    public RespResult login(LoginDto loginDto) {
        Map<String, Object> respResult = new HashMap<>();
        String account = loginDto.getAccount();
        UserAccount userAccount = userAccountMapper.selectOne(new QueryWrapper<UserAccount>().eq("account", account));
        if (userAccount == null) return RespResult.error("用户不存在");
        String type = userAccount.getType();
        if (type.equals(RoleTypeEnum.ADMIN.getValue())) {
            QueryWrapper<SysUser> wrapper = new QueryWrapper<>();
            wrapper.eq("user_name", loginDto.getAccount());
            wrapper.eq("password", loginDto.getPassword());
            SysUser sysUser = sysUserMapper.selectOne(wrapper);
            if (sysUser == null || sysUser.getStatus().equals("0"))
                return RespResult.error("用户名或密码错误或者已禁用");
            Field[] fields = sysUser.getClass().getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true); // 允许访问私有属性
                try {
                    Object value = field.get(sysUser);
                    if (value != null) { // 检查属性值是否为 null
                        respResult.put(field.getName(), value);
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace(); // 处理异常
                }
            }
        } else if (type.equals(RoleTypeEnum.CUST.getValue())) {
            CustInformation custInformation = custInformationService.login(loginDto);
            if (custInformation == null || custInformation.getStatus().equals("0"))
                return RespResult.error("用户名或密码错误或者已禁用");
            Field[] fields = custInformation.getClass().getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true); // 允许访问私有属性
                try {
                    Object value = field.get(custInformation);
                    if (value != null) { // 检查属性值是否为 null
                        respResult.put(field.getName(), value);
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace(); // 处理异常
                }
            }
        } else if (type.equals(RoleTypeEnum.FARMER.getValue())) {
            FarmerInformation farmerInformation = farmerInformationService.login(loginDto);
            if (farmerInformation == null || farmerInformation.getStatus().equals("0"))
                return RespResult.error("用户名或密码错误或者已禁用");
            Field[] fields = farmerInformation.getClass().getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true); // 允许访问私有属性
                try {
                    Object value = field.get(farmerInformation);
                    if (value != null) { // 检查属性值是否为 null
                        respResult.put(field.getName(), value);
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace(); // 处理异常
                }
            }
        }
        getRole(respResult, type);
        if (respResult.isEmpty()) return RespResult.error("用户不存在");
        return RespResult.ok(respResult);
    }

    @Override
    public void getRole(Map<String, Object> resultMap, String userType) {
        String id = (String) resultMap.get("id");
        QueryWrapper<SysAuthorityUserRole> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", id).eq("user_type", userType);
        SysAuthorityUserRole sysAuthorityUserRole = sysAuthorityUserRoleMapper.selectOne(wrapper);
        if (sysAuthorityUserRole == null) return;
        String[] roleIds = sysAuthorityUserRole.getRoleIds().split(",");
        ArrayList<String> roles = new ArrayList<>();
        for (String roleId : roleIds) {
            SysAuthorityRole sysAuthorityRole = sysAuthorityRoleMapper.selectById(roleId);
            roles.add(sysAuthorityRole.getRoleName());
        }
        resultMap.put("roles", roles);
    }

    @Override
    public Page<SysUser> getUsers(HashMap searchMap) {
        String username = (String) searchMap.getOrDefault("username", "");
        String createDateStr = (String) searchMap.get("createDate");
        boolean createDateStrNotNull = createDateStr != null && !createDateStr.equals("");
        if (createDateStrNotNull) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-M-d");
                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-M-d HH:mm:ss");
                Date parse = inputFormat.parse(createDateStr);
                createDateStr = outputFormat.format(parse);
            } catch (Exception e) {
                throw new RuntimeException("日期格式错误");
            }
        }
        QueryWrapper<SysUser> wrapper = new QueryWrapper<>();
        wrapper.like("user_name", username);
        wrapper.gt(createDateStrNotNull, "create_date", createDateStr);
        wrapper.eq("status", "1");
        int page = (int) searchMap.getOrDefault("page", "1");
        int pageSize = (int) searchMap.getOrDefault("pageSize", "10");
        Page<SysUser> pages = new Page<>(page, pageSize);
        return sysUserMapper.selectPage(pages, wrapper);
    }

    @Override
    public RespResult deleteById(String id) {
        SysUser sysUser = sysUserMapper.selectById(id);
        if (sysUser == null) return RespResult.error("用户不存在");
        if (sysUser.getStatus().equals("0")) {
            return RespResult.error("用户已禁用");
        }
        sysUser.setStatus("0");
        sysUserMapper.updateById(sysUser);
        return RespResult.ok("用户禁用成功");
    }
}
