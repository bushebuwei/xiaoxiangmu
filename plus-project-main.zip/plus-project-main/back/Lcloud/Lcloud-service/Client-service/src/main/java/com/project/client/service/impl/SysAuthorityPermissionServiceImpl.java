package com.project.client.service.impl;

import com.project.client.mapper.SysAuthorityRolePermissionMapper;
import com.project.client.model.SysAuthorityPermission;
import com.project.client.mapper.SysAuthorityPermissionMapper;
import com.project.client.model.SysAuthorityRolePermission;
import com.project.client.service.SysAuthorityPermissionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.util.RespResult;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
@Service
public class SysAuthorityPermissionServiceImpl extends ServiceImpl<SysAuthorityPermissionMapper, SysAuthorityPermission> implements SysAuthorityPermissionService {

    private final SysAuthorityRolePermissionMapper sysAuthorityRolePermissionMapper;
    private final SysAuthorityPermissionMapper sysAuthorityPermissionMapper;

    public SysAuthorityPermissionServiceImpl(SysAuthorityRolePermissionMapper sysAuthorityRolePermissionMapper, SysAuthorityPermissionMapper sysAuthorityPermissionMapper) {
        this.sysAuthorityRolePermissionMapper = sysAuthorityRolePermissionMapper;
        this.sysAuthorityPermissionMapper = sysAuthorityPermissionMapper;
    }

    @Override
    public RespResult getPermissionByRoleId(String roleId) {
        SysAuthorityRolePermission sysAuthorityRolePermission = sysAuthorityRolePermissionMapper.selectById(roleId);
        if (sysAuthorityRolePermission == null || sysAuthorityRolePermission.getStatus().equals("0"))
            return RespResult.error("角色不存在或者已禁用");
        String permIds = sysAuthorityRolePermission.getPermIds();
        String[] permIdList = permIds.split(",");
        ArrayList<String> permNames = new ArrayList<>();
        for (String permId : permIdList) {
            SysAuthorityPermission sysAuthorityPermission = sysAuthorityPermissionMapper.selectById(permId);
            String permName = sysAuthorityPermission.getPermName();
            permNames.add(permName);
        }
        return RespResult.ok(permNames);
    }
}
