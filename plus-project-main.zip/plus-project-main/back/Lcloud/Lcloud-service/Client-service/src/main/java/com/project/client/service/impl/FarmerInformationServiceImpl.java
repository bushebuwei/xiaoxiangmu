package com.project.client.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.dto.LoginDto;
import com.project.client.model.CustInformation;
import com.project.client.model.FarmerInformation;
import com.project.client.mapper.FarmerInformationMapper;
import com.project.client.model.SysUser;
import com.project.client.service.FarmerInformationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author cust
 * @since 2025-03-06
 */
@Service
public class FarmerInformationServiceImpl extends ServiceImpl<FarmerInformationMapper, FarmerInformation> implements FarmerInformationService {

    @Override
    public FarmerInformation login(LoginDto loginDto) {
        QueryWrapper<FarmerInformation> wrapper = new QueryWrapper<>();
        wrapper.eq("code", loginDto.getAccount()).eq("password", loginDto.getPassword());
        FarmerInformation farmerInformation = this.getOne(wrapper);
        if (farmerInformation == null) return null;
        return farmerInformation;
    }

    @Override
    public Page<FarmerInformation> getFarmerInformations(HashMap searchMap) {
        String username = (String) searchMap.getOrDefault("name", "");
        String createDateStr = (String) searchMap.get("createDate");
        boolean createDateStrNotNull = createDateStr != null && !createDateStr.equals("");
        if (createDateStrNotNull) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-M-d");
                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-M-d HH:mm:ss");
                Date parse = inputFormat.parse(createDateStr);
                createDateStr = outputFormat.format(parse);
            } catch (Exception e) {
                throw new RuntimeException("日期格式错误");
            }
        }
        QueryWrapper<FarmerInformation> wrapper = new QueryWrapper<>();
        wrapper.like("name", username);
        wrapper.gt(createDateStrNotNull, "create_date", createDateStr);
        wrapper.eq("status", "1");
        int page = (int) searchMap.getOrDefault("page", 1);
        int pageSize = (int) searchMap.getOrDefault("pageSize", 10);
        Page<FarmerInformation> pages = new Page<>(page, pageSize);
        return this.page(pages, wrapper);
    }
}
