package com.project.client.controller;

import com.project.client.dto.SysAuthorityUserDto;
import com.project.client.model.SysAuthorityRole;
import com.project.client.service.SysAuthorityRoleService;
import com.project.util.RespResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/sysAuthorityRole")
public class SysAuthorityRoleController {
    private final SysAuthorityRoleService sysAuthorityRoleService;

    public SysAuthorityRoleController(SysAuthorityRoleService sysAuthorityRoleService) {
        this.sysAuthorityRoleService = sysAuthorityRoleService;
    }

    @RequestMapping("/getRoles")
    public RespResult<List<SysAuthorityRole>> getRoles() {
        return RespResult.ok(sysAuthorityRoleService.list());
    }

    @RequestMapping("/addRole")
    @Transactional
    public RespResult addRole(@RequestBody SysAuthorityUserDto sysAuthorityUserDto) {
        return sysAuthorityRoleService.addRole(sysAuthorityUserDto);
    }

    @RequestMapping("/deleteRole/{roleId}")
    public RespResult deleteRole(@PathVariable String roleId) {
        return RespResult.ok(sysAuthorityRoleService.removeById(roleId));
    }
}
