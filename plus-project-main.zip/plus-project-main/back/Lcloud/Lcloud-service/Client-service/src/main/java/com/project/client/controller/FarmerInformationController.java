package com.project.client.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.model.FarmerInformation;
import com.project.client.model.SysUser;
import com.project.client.service.FarmerInformationService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
@RequestMapping("/farmerInformation")
public class FarmerInformationController {
    private final FarmerInformationService farmerInformationService;

    public FarmerInformationController(FarmerInformationService farmerInformationService) {
        this.farmerInformationService = farmerInformationService;
    }

    @RequestMapping("/getFarmerInformations")
    public RespResult<Page<FarmerInformation>> getFarmerInformations(@RequestBody HashMap searchMap) {
        Page<FarmerInformation> farmerInformationPage = farmerInformationService.getFarmerInformations(searchMap);
        return RespResult.ok(farmerInformationPage);
    }
}
