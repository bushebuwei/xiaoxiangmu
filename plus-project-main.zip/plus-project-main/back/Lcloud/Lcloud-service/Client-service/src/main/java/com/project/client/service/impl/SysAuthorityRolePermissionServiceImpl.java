package com.project.client.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.client.dto.SysRolePermissionDto;
import com.project.client.mapper.SysAuthorityPermissionMapper;
import com.project.client.mapper.SysAuthorityRoleMapper;
import com.project.client.model.SysAuthorityPermission;
import com.project.client.model.SysAuthorityRole;
import com.project.client.model.SysAuthorityRolePermission;
import com.project.client.mapper.SysAuthorityRolePermissionMapper;
import com.project.client.service.SysAuthorityRolePermissionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.util.RespResult;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
@Service
public class SysAuthorityRolePermissionServiceImpl extends ServiceImpl<SysAuthorityRolePermissionMapper, SysAuthorityRolePermission> implements SysAuthorityRolePermissionService {

    private final SysAuthorityRolePermissionMapper sysAuthorityRolePermissionMapper;

    private final SysAuthorityPermissionMapper sysAuthorityPermissionMapper;

    private final SysAuthorityRoleMapper sysAuthorityRoleMapper;

    public SysAuthorityRolePermissionServiceImpl(SysAuthorityRolePermissionMapper sysAuthorityRolePermissionMapper,
                                                 SysAuthorityPermissionMapper sysAuthorityPermissionMapper,
                                                 SysAuthorityRoleMapper sysAuthorityRoleMapper) {
        this.sysAuthorityRolePermissionMapper = sysAuthorityRolePermissionMapper;
        this.sysAuthorityPermissionMapper = sysAuthorityPermissionMapper;
        this.sysAuthorityRoleMapper = sysAuthorityRoleMapper;
    }

    @Override
    public RespResult getRoleAndPermission() {
        List<SysRolePermissionDto> rolePermissionList = new ArrayList<>();
        List<SysAuthorityRolePermission> sysAuthorityRolePermissions =
                sysAuthorityRolePermissionMapper.selectList(new QueryWrapper<>());
        sysAuthorityRolePermissions.forEach(rolePermission -> {
            SysRolePermissionDto rolePermissionDto = new SysRolePermissionDto();
            String roleId = rolePermission.getRoleId();
            String[] permIdList = rolePermission.getPermIds().split(",");
            SysAuthorityRole sysAuthorityRole = sysAuthorityRoleMapper.selectById(roleId);
            rolePermissionDto.setSysAuthorityRole(sysAuthorityRole);
            ArrayList<SysAuthorityPermission> permissionList = new ArrayList<>();
            for (String permId : permIdList) {
                SysAuthorityPermission authorityPermission = sysAuthorityPermissionMapper.selectById(permId);
                permissionList.add(authorityPermission);
            }
            rolePermissionDto.setSysAuthorityPermissionList(permissionList);
            rolePermissionList.add(rolePermissionDto);
        });
        return RespResult.ok(rolePermissionList);
    }
}
