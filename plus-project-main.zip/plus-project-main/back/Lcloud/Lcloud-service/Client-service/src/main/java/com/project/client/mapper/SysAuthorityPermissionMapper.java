package com.project.client.mapper;

import com.project.client.model.SysAuthorityPermission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author cust
 * @since 2025-02-21
 */
public interface SysAuthorityPermissionMapper extends BaseMapper<SysAuthorityPermission> {

}

