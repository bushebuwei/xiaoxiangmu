package com.project.client.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.mapper.FarmerInformationMapper;
import com.project.client.model.FarmerInformation;
import com.project.client.model.OrderHead;
import com.project.client.model.SettlementInvite;
import com.project.client.mapper.SettlementInviteMapper;
import com.project.client.service.FarmerInformationService;
import com.project.client.service.SettlementInviteService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lemon
 * @since 2025-04-05
 */
@Service
public class SettlementInviteServiceImpl extends ServiceImpl<SettlementInviteMapper, SettlementInvite> implements SettlementInviteService {

    private final FarmerInformationMapper farmerInformationMapper;

    public SettlementInviteServiceImpl(FarmerInformationMapper farmerInformationMapper) {
        this.farmerInformationMapper = farmerInformationMapper;
    }

    @Override
    public Page<SettlementInvite> getSettlementInvite(HashMap searchMap) {
        String inviteName = (String) searchMap.getOrDefault("inviteName", "");
        String createDateStr = (String) searchMap.get("inviteTime");
        boolean createDateStrNotNull = createDateStr != null && !createDateStr.equals("");
        if (createDateStrNotNull) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-M-d");
                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-M-d HH:mm:ss");
                Date parse = inputFormat.parse(createDateStr);
                createDateStr = outputFormat.format(parse);
            } catch (Exception e) {
                throw new RuntimeException("日期格式错误");
            }
        }
        QueryWrapper<SettlementInvite> wrapper = new QueryWrapper<>();
        wrapper.like("invite_name", inviteName);
        wrapper.gt(createDateStrNotNull, "invite_time", createDateStr);
        int page = (int) searchMap.getOrDefault("page", 1);
        int pageSize = (int) searchMap.getOrDefault("pageSize", 5);
        Page<SettlementInvite> pages = new Page<>(page, pageSize);

        Page<SettlementInvite> settlementPage = this.page(pages, wrapper);

        List<SettlementInvite> settlementInvites = settlementPage.getRecords();

        List<String> recipientIds = settlementInvites.stream().map(SettlementInvite::getRecipient)
                .distinct()
                .collect(Collectors.toList());

        HashMap<String, String> recipientMap = new HashMap<>();
        if (!recipientIds.isEmpty()) {
            List<FarmerInformation> farmerInformations = farmerInformationMapper.selectBatchIds(recipientIds);
            for (FarmerInformation farmer : farmerInformations) {
                recipientMap.put(farmer.getId(), farmer.getNickname());
            }
        }

        for (SettlementInvite settlementInvite : settlementInvites) {
            String recipient = settlementInvite.getRecipient();
            String farmerNickName = recipientMap.get(recipient);
            settlementInvite.setRecipient(farmerNickName);
        }

        Page<SettlementInvite> resultPage = new Page<>(pages.getCurrent(), pages.getSize(), pages.getTotal());
        resultPage.setRecords(settlementInvites);
        return resultPage;
    }
}
