package com.project.client.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.project.client.model.PubEnterprise;

public interface PubEnterpriseMapper extends BaseMapper<PubEnterprise> {
}
