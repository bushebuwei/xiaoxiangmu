package com.project.client.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.client.dto.LoginDto;
import com.project.client.model.SysUser;
import com.project.util.RespResult;

import java.util.HashMap;
import java.util.Map;

public interface SysUserService extends IService<SysUser> {
    RespResult login(LoginDto loginDto);

    void getRole(Map<String, Object> resultMap, String userType);

    Page<SysUser> getUsers(HashMap searchMap);

    RespResult deleteById(String id);
}
