package com.project.client.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.project.client.model.PubEnterprise;

public interface PubEnterpriseService extends IService<PubEnterprise> {
}
