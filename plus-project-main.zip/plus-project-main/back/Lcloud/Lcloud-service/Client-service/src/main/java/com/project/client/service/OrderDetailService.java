package com.project.client.service;

import com.project.client.model.OrderDetail;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lemon
 * @since 2025-03-11
 */
public interface OrderDetailService extends IService<OrderDetail> {

}
