package com.project.client.service.impl;

import com.project.client.model.SettlementMain;
import com.project.client.mapper.SettlementMainMapper;
import com.project.client.service.SettlementMainService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author lemon
 * @since 2025-04-05
 */
@Service
public class SettlementMainServiceImpl extends ServiceImpl<SettlementMainMapper, SettlementMain> implements SettlementMainService {

}
