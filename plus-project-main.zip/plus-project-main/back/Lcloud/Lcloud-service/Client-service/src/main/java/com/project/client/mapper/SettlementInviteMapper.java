package com.project.client.mapper;

import com.project.client.model.SettlementInvite;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lemon
 * @since 2025-04-05
 */
public interface SettlementInviteMapper extends BaseMapper<SettlementInvite> {

}

