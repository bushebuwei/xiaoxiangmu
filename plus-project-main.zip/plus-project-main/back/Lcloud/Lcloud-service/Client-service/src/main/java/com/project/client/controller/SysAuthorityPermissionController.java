package com.project.client.controller;

import com.project.client.model.SysAuthorityPermission;
import com.project.client.service.SysAuthorityPermissionService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/sysAuthorityPermission")
public class SysAuthorityPermissionController {
    private final SysAuthorityPermissionService sysAuthorityPermissionService;

    public SysAuthorityPermissionController(SysAuthorityPermissionService sysAuthorityPermissionService) {
        this.sysAuthorityPermissionService = sysAuthorityPermissionService;
    }

    @RequestMapping("/addPermission")
    public RespResult addPermission(@RequestBody SysAuthorityPermission sysAuthorityPermission) {
        return RespResult.ok(sysAuthorityPermissionService.save(sysAuthorityPermission));
    }

    @RequestMapping("/getPermission/{roleId}")
    public RespResult getPermissionByRoleId(@PathVariable String roleId) {
        return RespResult.ok(sysAuthorityPermissionService.getPermissionByRoleId(roleId));
    }

    @RequestMapping("/getPermissions")
    public RespResult<List<SysAuthorityPermission>> getPermissions() {
        return RespResult.ok(sysAuthorityPermissionService.list());
    }
}
