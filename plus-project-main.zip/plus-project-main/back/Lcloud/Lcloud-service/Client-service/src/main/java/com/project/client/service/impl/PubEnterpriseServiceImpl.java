package com.project.client.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.client.mapper.PubEnterpriseMapper;
import com.project.client.model.PubEnterprise;
import com.project.client.service.PubEnterpriseService;
import org.springframework.stereotype.Service;

@Service
public class PubEnterpriseServiceImpl extends ServiceImpl<PubEnterpriseMapper, PubEnterprise> implements PubEnterpriseService {
}
