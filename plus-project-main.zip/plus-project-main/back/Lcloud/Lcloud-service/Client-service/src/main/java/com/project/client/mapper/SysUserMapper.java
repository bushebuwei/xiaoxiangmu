package com.project.client.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.project.client.dto.LoginDto;
import com.project.client.model.SysUser;
import com.project.util.RespResult;

public interface SysUserMapper extends BaseMapper<SysUser> {
}
