package com.project.client.controller;

import com.project.client.service.PubEnterpriseService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pubEnterprise")
public class PubEnterpriseController {
    private final PubEnterpriseService pubEnterpriseService;

    public PubEnterpriseController(PubEnterpriseService pubEnterpriseService) {
        this.pubEnterpriseService = pubEnterpriseService;
    }

    @RequestMapping("/getEnterprises")
    public RespResult getEnterpriseList() {
        return RespResult.ok(pubEnterpriseService.list());
    }
}
