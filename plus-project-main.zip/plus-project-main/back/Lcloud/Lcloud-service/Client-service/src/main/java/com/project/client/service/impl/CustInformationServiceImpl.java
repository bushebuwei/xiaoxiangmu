package com.project.client.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.client.dto.CustInfoSearchDto;
import com.project.client.dto.LoginDto;
import com.project.client.mapper.CustInformationMapper;
import com.project.client.model.CustInformation;
import com.project.client.model.SysUser;
import com.project.client.service.CustInformationService;
import com.project.util.RespResult;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CustInformationServiceImpl extends ServiceImpl<CustInformationMapper, CustInformation> implements CustInformationService {
    private final CustInformationMapper custInformationMapper;

    public CustInformationServiceImpl(CustInformationMapper custInformationMapper) {
        this.custInformationMapper = custInformationMapper;
    }


    @Override
    public CustInformation login(LoginDto loginDto) {
        QueryWrapper<CustInformation> wrapper = new QueryWrapper<>();
        wrapper.eq("code", loginDto.getAccount()).eq("password", loginDto.getPassword());
        CustInformation custInformation = custInformationMapper.selectOne(wrapper);
        if (custInformation == null) return null;
        return custInformation;
    }

    @Override
    public Page<CustInformation> getCustUsers(HashMap searchMap) {
        String username = (String) searchMap.getOrDefault("name", "");
        String createDateStr = (String) searchMap.get("createDate");
        boolean createDateStrNotNull = createDateStr != null && !createDateStr.equals("");
        if (createDateStrNotNull) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-M-d");
                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-M-d HH:mm:ss");
                Date parse = inputFormat.parse(createDateStr);
                createDateStr = outputFormat.format(parse);
            } catch (Exception e) {
                throw new RuntimeException("日期格式错误");
            }
        }
        QueryWrapper<CustInformation> wrapper = new QueryWrapper<>();
        wrapper.like("name", username);
        wrapper.gt(createDateStrNotNull, "create_date", createDateStr);
        wrapper.eq("status", "1");
        int page = (int) searchMap.getOrDefault("page", "1");
        int pageSize = (int) searchMap.getOrDefault("pageSize", "10");
        Page<CustInformation> pages = new Page<>(page, pageSize);
        return custInformationMapper.selectPage(pages, wrapper);
    }

    @Override
    public List<Map<String, String>> getCustNames() {
        List<CustInformation> custInformations = this.list();
        return custInformations.stream().map(custInformation -> {
            Map<String, String> map = new HashMap<>();
            map.put("custId", custInformation.getId());
            map.put("name", custInformation.getName());
            return map;
        }).collect(Collectors.toList());
    }
}
