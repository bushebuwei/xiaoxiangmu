package com.project.client.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.model.OrderHead;
import com.project.client.model.SysUser;
import com.project.client.service.OrderHeadService;
import com.project.util.RespResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author lemon
 * @since 2025-03-11
 */
@RestController
@RequestMapping("/orderHead")
public class OrderHeadController {
    private final OrderHeadService orderHeadService;

    public OrderHeadController(OrderHeadService orderHeadService) {
        this.orderHeadService = orderHeadService;
    }

    @RequestMapping("/getOrderHeads")
    public RespResult<Page<OrderHead>> getOrderHeads(@RequestBody HashMap searchMap) {
        Page<OrderHead> orderHeadPages = orderHeadService.getOrderHeads(searchMap);
        return RespResult.ok(orderHeadPages);
    }

    @RequestMapping("/addOrder")
    public RespResult addOrder(@RequestBody HashMap<String, String> orderMap) {
        return RespResult.ok(orderHeadService.addOrder(orderMap));
    }
}
