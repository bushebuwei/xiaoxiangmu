package com.project.client.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.mapper.CustInformationMapper;
import com.project.client.model.CustInformation;
import com.project.client.model.FarmerProduct;
import com.project.client.model.OrderDetail;
import com.project.client.model.OrderHead;
import com.project.client.mapper.OrderHeadMapper;
import com.project.client.service.FarmerProductService;
import com.project.client.service.OrderDetailService;
import com.project.client.service.OrderHeadService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.util.RespResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author lemon
 * @since 2025-03-11
 */
@Service
public class OrderHeadServiceImpl extends ServiceImpl<OrderHeadMapper, OrderHead> implements OrderHeadService {

    private final CustInformationMapper custInformationMapper;

    private final OrderDetailService orderDetailService;

    private final FarmerProductService farmerProductService;

    public OrderHeadServiceImpl(CustInformationMapper custInformationMapper, OrderDetailService orderDetailService, FarmerProductService farmerProductService) {
        this.custInformationMapper = custInformationMapper;
        this.orderDetailService = orderDetailService;
        this.farmerProductService = farmerProductService;
    }

    @Override
    public Page<OrderHead> getOrderHeads(HashMap searchMap) {
        String orderId = (String) searchMap.getOrDefault("orderId", "");
        String createDateStr = (String) searchMap.get("orderDate");
        boolean createDateStrNotNull = createDateStr != null && !createDateStr.equals("");
        if (createDateStrNotNull) {
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-M-d");
                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-M-d HH:mm:ss");
                Date parse = inputFormat.parse(createDateStr);
                createDateStr = outputFormat.format(parse);
            } catch (Exception e) {
                throw new RuntimeException("日期格式错误");
            }
        }
        QueryWrapper<OrderHead> wrapper = new QueryWrapper<>();
        wrapper.like("order_id", orderId);
        wrapper.gt(createDateStrNotNull, "order_date", createDateStr);
        int page = (int) searchMap.getOrDefault("page", "1");
        int pageSize = (int) searchMap.getOrDefault("pageSize", "10");
        Page<OrderHead> pages = new Page<>(page, pageSize);

        Page<OrderHead> orderPage = this.page(pages, wrapper);

        List<OrderHead> orders = orderPage.getRecords();

        List<String> custIds = orders.stream().map(OrderHead::getCustId)
                .distinct()
                .collect(Collectors.toList());

        HashMap<String, String> custMap = new HashMap<>();
        if (!custIds.isEmpty()) {
            List<CustInformation> custInformations = custInformationMapper.selectBatchIds(custIds);
            for (CustInformation cust : custInformations) {
                custMap.put(cust.getId(), cust.getName());
            }
        }

        for (OrderHead order : orders) {
            String custId = order.getCustId();
            String custName = custMap.get(custId);
            order.setCustName(custName);
        }

        Page<OrderHead> resultPage = new Page<>(orderPage.getCurrent(), orderPage.getSize(), orderPage.getTotal());
        resultPage.setRecords(orders);

        return resultPage;
    }

    @Override
    @Transactional
    public RespResult addOrder(HashMap<String, String> orderMap) {
        String addrId = orderMap.get("addrId");
        String custId = orderMap.get("custId");
        String logStatus = orderMap.get("logStatus");
        String orderStatus = orderMap.get("orderStatus");
        String payMethod = orderMap.get("payMethod");
        String productId = orderMap.get("productId");
        String productQuantity = orderMap.get("productQuantity");
        String signatory = orderMap.get("signatory");
        String unitPrice = orderMap.get("unitPrice");

        OrderHead orderHead = new OrderHead();
        orderHead.setCustId(custId);
        orderHead.setAddrId(addrId);
        orderHead.setLogStatus(logStatus);
        orderHead.setOrderStatus(orderStatus);
        orderHead.setPayMethod(payMethod);
        orderHead.setSignatory(signatory);
        orderHead.setOrderDate(new Date());

        this.save(orderHead);

        FarmerProduct farmerProduct = farmerProductService.getById(productId);

        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setOrderId(orderHead.getOrderId());
        orderDetail.setFprodName(farmerProduct.getProductName());
        orderDetail.setFprodId(farmerProduct.getId());
        orderDetail.setFprodDesc(farmerProduct.getProductDesc());
        orderDetail.setOrderQty(Integer.parseInt(productQuantity));
        orderDetail.setOrderUnit("个");
        orderDetail.setCost(farmerProduct.getProductSize());
        orderDetail.setCostUnit(unitPrice);

        orderDetailService.save(orderDetail);
        return RespResult.ok("订单新增成功");
    }
}
