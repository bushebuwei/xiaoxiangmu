package com.project.client.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.project.client.model.UserAccount;

public interface UserAccountService extends IService<UserAccount> {
}
