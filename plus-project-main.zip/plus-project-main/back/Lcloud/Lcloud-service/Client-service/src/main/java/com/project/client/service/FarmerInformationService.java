package com.project.client.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.project.client.dto.LoginDto;
import com.project.client.model.FarmerInformation;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.HashMap;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author cust
 * @since 2025-03-06
 */
public interface FarmerInformationService extends IService<FarmerInformation> {

    FarmerInformation login(LoginDto loginDto);

    Page<FarmerInformation> getFarmerInformations(HashMap searchMap);
}
