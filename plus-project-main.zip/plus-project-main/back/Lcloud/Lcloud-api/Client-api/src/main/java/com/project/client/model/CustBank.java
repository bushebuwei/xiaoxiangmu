package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("cust_bank")
public class CustBank implements Serializable {
    @TableId(type = IdType.ASSIGN_ID)
    private String custId;
    private String bankCode;
    private String accountNo;
    private String type;
    private Date createDate;
    private Date updateDate;
}
