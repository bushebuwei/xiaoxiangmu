package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * <p>
 *
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
@Getter
@Setter
@ToString
@TableName("farm_information")
public class FarmInformation implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 产户id
     */
    private String farmerId;

    /**
     * 农场编号
     */
    private String farmCode;

    /**
     * 农场名称
     */
    private String farmName;

    /**
     * 收货详细地址
     */
    private String address;

    /**
     * 农场简介
     */
    private String introduce;

    /**
     * 农场负责人
     */
    private String director;

    /**
     * 联系电话
     */
    private String telephone;

    /**
     * 手机号
     */
    private String cellphone;

    /**
     * 客服
     */
    private String custService;

    /**
     * 更新日期
     */
    private LocalDateTime updateDate;

    /**
     * 备注
     */
    private String remarks;
}
