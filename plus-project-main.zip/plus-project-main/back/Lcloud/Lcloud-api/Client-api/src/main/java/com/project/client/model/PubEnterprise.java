package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("pub_enterprise")
public class PubEnterprise implements Serializable {
    @TableId(type = IdType.ASSIGN_ID)
    private String id;
    private String name;
    private String code;
    private Integer type;
}
