package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;

import lombok.*;

/**
 * <p>
 *
 * </p>
 *
 * @author cust
 * @since 2025-03-06
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("farmer_information")
public class FarmerInformation implements Serializable {

    /**
     * 产户id
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 产户账号
     */
    private String code;

    /**
     * 登录密码
     */
    private String password;

    /**
     * 产户姓名
     */
    private String name;

    /**
     * 昵称
     */
    private String nickname;

    /**
     * 性别 M-男 F-女
     */
    private String gender;

    /**
     * 头像照片文件名
     */
    private String photoFile;

    /**
     * 出生日期
     */
    private Date dateOfBirth;

    /**
     * 身份证号
     */
    private String idNo;

    /**
     * 身份证正面
     */
    private String fontOfId;

    /**
     * 身份证反面
     */
    private String backOfId;

    /**
     * 联系电话
     */
    private String telephone;

    /**
     * 手机号
     */
    private String cellphone;

    /**
     * 微信号
     */
    private String wechat;

    /**
     * qq号
     */
    private String qq;

    /**
     * 电子邮件
     */
    private String emailAddress;

    /**
     * 审核标志 0-未通过 1-通过
     */
    private String auditFlag;

    /**
     * 创建日期
     */
    private Date createDate;

    /**
     * 状态 1-正常 2-注销
     */
    private String status;

    /**
     * 更新日期
     */
    private Date updateDate;
}
