package com.project.client.dto;


import com.project.client.model.SysUser;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SysUserDto implements Serializable {
    private SysUser sysUser;
    private List<String> roleIds;
}
