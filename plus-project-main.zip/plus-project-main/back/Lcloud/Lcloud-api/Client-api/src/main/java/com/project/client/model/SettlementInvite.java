package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.*;

/**
 * <p>
 * 
 * </p>
 *
 * @author lemon
 * @since 2025-04-05
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("settlement_invite")
public class SettlementInvite implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 邀请单号
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 邀请名称
     */
    private String inviteName;

    /**
     * 结算周期
     */
    private String settlementCycle;

    /**
     * 结算方式
     */
    private String settlementType;

    /**
     * 发起方
     */
    private String initiator;

    /**
     * 发起日期
     */
    private Date inviteTime;

    /**
     * 接受方
     */
    private String recipient;

    /**
     * 确定时间
     */
    private Date confirmTime;

    /**
     * 状态
     */
    private String status;

    /**
     * 备注
     */
    private String remark;
}
