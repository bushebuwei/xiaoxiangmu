package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.*;

/**
 * <p>
 *
 * </p>
 *
 * @author lemon
 * @since 2025-03-11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("order_head")
public class OrderHead implements Serializable {


    /**
     * 订单编号
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String orderId;

    /**
     * 客户id
     */
    private String custId;


    @TableField(exist = false)
    private String custName;

    /**
     * 订单状态 1-已支付 2-已接单 3-已发货 4-已签收
     */
    private String orderStatus;

    /**
     * 订单时间
     */
    private Date orderDate;

    /**
     * 地址id
     */
    private String addrId;

    /**
     * 支付方式
     */
    private String payMethod;

    /**
     * 支付时间
     */
    private Date payDate;

    /**
     * 发货时间
     */
    private Date deliverDate;

    /**
     * 物流状态
     */
    private String logStatus;

    /**
     * 到达时间
     */
    private Date arrivalDate;

    /**
     * 签收人
     */
    private String signatory;

    /**
     * 签单时间
     */
    private Date signingDate;
}
