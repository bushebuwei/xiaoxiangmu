package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("cust_address")
public class CustAddress implements Serializable {
    @TableId(type = IdType.ASSIGN_ID)
    private String addrId;
    private String custId;
    private Integer seqNo;
    private String receiver;
    private String cellPhone;
    private String area;
    private String address;
    private Date createDate;
    private Date updateDate;
    private String isDefault;
}
