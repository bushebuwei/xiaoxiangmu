package com.project.client.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SysAuthorityUserDto implements Serializable {
    private String roleName;
    private String roleValue;
    private List<String> permissions;
}
