package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("sys_authority_role")
public class SysAuthorityRole {
    @TableId(type = IdType.ASSIGN_ID)
    private String roleId;
    private String roleName;
    private String roleValue;
}
