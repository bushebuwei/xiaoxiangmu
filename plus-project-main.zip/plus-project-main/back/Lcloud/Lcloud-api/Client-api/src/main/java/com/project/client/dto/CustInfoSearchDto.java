package com.project.client.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
public class CustInfoSearchDto implements Serializable {
    private String name;
    private String nickName;
    private String telephone;
    private String idNo;
    private String enterprise;
}
