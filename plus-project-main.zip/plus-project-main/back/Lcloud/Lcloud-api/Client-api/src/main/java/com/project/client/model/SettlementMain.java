package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.*;

/**
 * <p>
 * 
 * </p>
 *
 * @author lemon
 * @since 2025-04-05
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("settlement_main")
public class SettlementMain implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 系统id
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 邀请单号
     */
    private String inviteId;

    /**
     * 交易总金额
     */
    private String transactionMoney;

    /**
     * 手续比例
     */
    private String procedureRate;

    /**
     * 手续费总金额
     */
    private String procedureMoney;

    /**
     * 金额单位
     */
    private String procedureUnit;

    /**
     * 结算方式
     */
    private String settlementType;

    /**
     * 产户账号
     */
    private String farmerCode;

    /**
     * 支出金额
     */
    private String settlementAmount;

    /**
     * 支付日期
     */
    private Date settlementTime;

    /**
     * 平台账号
     */
    private String sysCode;

    /**
     * 收款金额
     */
    private String receivedAmout;

    /**
     * 收款时间
     */
    private Date receivedTime;

    /**
     * 差额
     */
    private String difference;

    /**
     * 平台方签字
     */
    private String platformSignature;

    /**
     * 平台方确认日期
     */
    private Date platformConfirmTime;

    /**
     * 产户方签字
     */
    private String farmerSignature;

    /**
     * 产户方确认日期
     */
    private Date farmerConfirmTime;

    /**
     * 备注
     */
    private String remark;
}
