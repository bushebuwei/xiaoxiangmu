package com.project.client.myEnum;

import lombok.Data;
import lombok.Getter;

@Getter
public enum RoleTypeEnum {
    ADMIN("admin", "1"),
    CUST("cust", "2"),
    FARMER("farmer", "3");

    private String roleType;
    private String value;

    RoleTypeEnum(String roleType, String value) {
        this.roleType = roleType;
        this.value = value;
    }


    public void setRoleType(String roleType) {
        this.roleType = roleType;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
