package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.*;

/**
 * <p>
 *
 * </p>
 *
 * @author lemon
 * @since 2025-03-11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("order_detail")
public class OrderDetail implements Serializable {


    /**
     * 序号
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String seqNo;
    /**
     * 订单id
     */
    private String orderId;


    /**
     * 农产品编号
     */
    private String fprodId;

    /**
     * 农产品描述
     */
    private String fprodDesc;

    private String fprodName;

    /**
     * 订购数量
     */
    private Integer orderQty;

    /**
     * 数量单位 来自 pub_unit
     */
    private String orderUnit;

    /**
     * 单价
     */
    private Double cost;

    /**
     * 单价单位，默认元
     */
    private String costUnit;

    /**
     * 接收数
     */
    private Integer receivedQty;

    /**
     * 接收时间
     */
    private Date receivedDate;

    /**
     * 是否退货 0-否 1-是
     */
    private String returnStatus;

    /**
     * 已退货数量
     */
    private Integer rejectQty;

    /**
     * 退货时刻
     */
    private Date rejectDate;

    /**
     * 备注
     */
    private String remarks;
}
