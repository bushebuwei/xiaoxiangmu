package com.project.client.dto;

import com.project.client.model.SysAuthorityPermission;
import com.project.client.model.SysAuthorityRole;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SysRolePermissionDto implements Serializable {
    private SysAuthorityRole sysAuthorityRole;
    private List<SysAuthorityPermission> sysAuthorityPermissionList;
}
