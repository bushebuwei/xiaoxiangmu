package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("sys_authority_role_permission")
public class SysAuthorityRolePermission {
    @TableId(type = IdType.ASSIGN_ID)
    private String id;
    private String roleId;
    private String permIds;
    private String status;
    private Date createDate;
}
