package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;

import lombok.*;

/**
 * <p>
 *
 * </p>
 *
 * @author cust
 * @since 2025-03-07
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("farmer_product")
public class FarmerProduct implements Serializable {


    /**
     * 农产品id
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     * 农场编号
     */
    private String farmId;

    /**
     * 产户id
     */
    private String farmerId;

    /**
     * 农产品名称
     */
    private String productName;

    /**
     * 数量
     */
    private Integer count;

    /**
     * 数量单位
     */
    private String countUnit;

    /**
     * 单价
     */
    private Double price;

    /**
     * 单价单位
     */
    private String priceUnit;

    /**
     * 规格
     */
    private String spec;

    /**
     * 品质类别
     */
    private String qualityCategory;

    /**
     * 尺寸
     */
    private Double productSize;

    /**
     * 颜色
     */
    private String productColor;

    /**
     * 部位
     */
    private String productPart;

    /**
     * 包装方式
     */
    private String packageMethod;

    /**
     * 存储方式
     */
    private String storage;

    /**
     * 农产品简介
     */
    private String productDesc;

    /**
     * 备注
     */
    private String remark;

    /**
     * 状态 0- 现售 1-限售 2-预售 3-售完 4-已下架
     */
    private String status;

    /**
     * 上架日期
     */
    private Date createDate;

    /**
     * 经手人
     */
    private String handler;
}
