package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("cust_information")
public class CustInformation implements Serializable {
    @TableId(type = IdType.ASSIGN_ID)
    private String id;
    private String code;
    private String password;
    private String name;
    private String nickName;
    private String gender;
    private String photoFile;
    private Date dateOfBirth;
    private String idNo;
    private String fontOfId;
    private String backOfId;
    private String enterpriseCode;
    private String enterprise;
    private String entAddress;
    private String telephone;
    private String cellphone;
    private String wechat;
    private String qq;
    private String emailAddress;
    private Date createDate;
    private String status;
    private Date updateDate;

}
