package com.project.client.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("sys_authority_permission")
public class SysAuthorityPermission {
    @TableId(type = IdType.ASSIGN_ID)
    private String permId;
    private String permName;
    private String permValue;
}
