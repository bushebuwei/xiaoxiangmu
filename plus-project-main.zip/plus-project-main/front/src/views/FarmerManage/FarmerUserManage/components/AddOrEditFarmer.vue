<template>
    <a-modal
        :title="isEdit ? '修改农户' : '新增农户'"
        :open="props.open"
        width="800px"
        @ok="handleSubmit"
        @cancel="emit('close')"
    >
        <a-form ref="formRef" :model="formState" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-form-item label="账号" name="code">
                <a-input v-model:value="formState.code" placeholder="请输入账号" />
            </a-form-item>
            <a-form-item label="密码" name="password">
                <a-input-password v-model:value="formState.password" placeholder="请输入密码" />
            </a-form-item>
            <a-form-item label="农户名称" name="name">
                <a-input v-model:value="formState.name" placeholder="请输入农户名称" />
            </a-form-item>
            <a-form-item label="昵称" name="nickname">
                <a-input v-model:value="formState.nickname" placeholder="请输入昵称" />
            </a-form-item>
            <a-form-item label="性别" name="gender">
                <a-select v-model:value="formState.gender" placeholder="请选择性别">
                    <a-select-option value="M">男</a-select-option>
                    <a-select-option value="F">女</a-select-option>
                </a-select>
            </a-form-item>
            <!-- <a-form-item label="出生日期" name="dateOfBirth">
                <a-date-picker v-model:value="formState.dateOfBirth" style="width: 100%" />
            </a-form-item> -->
            <a-form-item label="身份证号" name="idNo">
                <a-input v-model:value="formState.idNo" placeholder="请输入身份证号" />
            </a-form-item>
            <a-form-item label="身份证正面" name="fontOfId">
                <a-input v-model:value="formState.fontOfId" placeholder="请上传身份证正面照片" />
            </a-form-item>
            <a-form-item label="身份证反面" name="backOfId">
                <a-input v-model:value="formState.backOfId" placeholder="请上传身份证反面照片" />
            </a-form-item>
            <a-form-item label="手机号码" name="cellphone">
                <a-input v-model:value="formState.cellphone" placeholder="请输入手机号码" />
            </a-form-item>
            <a-form-item label="固定电话" name="telephone">
                <a-input v-model:value="formState.telephone" placeholder="请输入固定电话" />
            </a-form-item>
            <a-form-item label="邮箱地址" name="emailAddress">
                <a-input v-model:value="formState.emailAddress" placeholder="请输入邮箱地址" />
            </a-form-item>
            <a-form-item label="QQ" name="qq">
                <a-input v-model:value="formState.qq" placeholder="请输入QQ" />
            </a-form-item>
            <a-form-item label="微信" name="wechat">
                <a-input v-model:value="formState.wechat" placeholder="请输入微信" />
            </a-form-item>
            <a-form-item label="状态" name="status">
                <a-select v-model:value="formState.status" placeholder="请选择状态">
                    <a-select-option value="1">启用</a-select-option>
                    <a-select-option value="0">禁用</a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="审核状态" name="auditFlag">
                <a-select v-model:value="formState.auditFlag" placeholder="请选择审核状态">
                    <a-select-option value="1">已审核</a-select-option>
                    <a-select-option value="0">未审核</a-select-option>
                </a-select>
            </a-form-item>
        </a-form>
    </a-modal>
</template>

<script setup lang="ts">
import { type FormInstance } from 'ant-design-vue'
import { message } from 'ant-design-vue'
import type { UnwrapRef } from 'vue'
import type { Rule } from 'ant-design-vue/es/form'
// import { addFarmerUser } from '@/services/farmerInformation'

defineOptions({
    name: 'AddOrEditFarmer'
})

const props = defineProps({
    open: Boolean,
    editData: {
        type: Object,
        default: null
    }
})

const emit = defineEmits(['success', 'close'])

const labelCol = { span: 6 }
const wrapperCol = { span: 16 }

interface FormState {
    code: string
    password: string
    name: string
    nickname: string
    gender: string
    // dateOfBirth: string | null
    idNo: string
    fontOfId: string
    backOfId: string
    cellphone: string
    telephone: string
    emailAddress: string
    qq: string
    wechat: string
    status: string
    auditFlag: string
    photoFile: string | null
}

const initialFormState: FormState = {
    code: '',
    password: '',
    name: '',
    nickname: '',
    gender: 'M',
    // dateOfBirth: '',
    idNo: '',
    fontOfId: '',
    backOfId: '',
    cellphone: '',
    telephone: '',
    emailAddress: '',
    qq: '',
    wechat: '',
    status: '1',
    auditFlag: '0',
    photoFile: ''
}

const formRef = ref<FormInstance>()
const formState: UnwrapRef<FormState> = reactive({
    ...initialFormState
})

const rules = {
    code: [{ required: true, message: '请输入账号' }],
    password: [{ required: true, message: '请输入密码' }],
    name: [{ required: true, message: '请输入农户名称' }],
    gender: [{ required: true, message: '请选择性别' }],
    idNo: [{ required: true, message: '请输入身份证号' }],
    cellphone: [{ required: true, message: '请输入手机号码' }],
    status: [{ required: true, message: '请选择状态' }]
}

const handleSubmit = () => {
    formRef.value?.validate().then(async () => {
        try {
            const data = toRaw(formState)
            let res
            if (isEdit.value) {
                console.log('编辑农户', data)
            } else {
                // res = await addFarmerUser(data)
            }
            emit('success')
            message.success('操作成功')
        } catch (error) {
            console.log('error', error)
        }
    })
}

const isEdit = computed(() => {
    return props.editData && Object.keys(props.editData).length > 0
})

const resetForm = () => {
    formRef.value?.resetFields()
    Object.assign(formState, initialFormState)
}

watch(
    () => props.open,
    newVal => {
        if (newVal) {
            if (isEdit.value) {
                Object.assign(formState, props.editData)
            }
        } else {
            resetForm()
        }
    }
)
</script>
