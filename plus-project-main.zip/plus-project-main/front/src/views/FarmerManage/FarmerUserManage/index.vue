<template>
    <div class="page-container">
        <div class="form-area">
            <div class="left-section">
                <div class="forms">
                    <a-input v-model:value="searchMap.name" allowClear placeholder="请输入查询的农户名称" />
                    <a-date-picker
                        v-model:value="searchMap.createDate"
                        value-format="YYYY-MM-DD"
                        placeholder="请选择创建日期"
                    />
                    <a-button type="primary" @click="handleSearch">查询</a-button>
                </div>
            </div>
            <a-button type="primary" @click="open = true">新增</a-button>
        </div>
        <div class="content-area">
            <a-table
                :columns="columns"
                :row-key="(record:any) => record.id"
                :data-source="tableData"
                :pagination="{
                    total: pagination.total,
                    current: pagination.current,
                    pageSize: pagination.pageSize,
                    pageSizeOptions: pagination.pageSizeOptions,
                    showSizeChanger: true
                }"
                :loading="loading"
                @change="handleTableChange"
            >
                <template #bodyCell="{ column, record }">
                    <template v-if="column.key === 'action'">
                        <div>
                            <a-button type="primary" size="small" @click="handleEdit(record)">编辑</a-button>
                            <a-button danger type="text" size="small" @click="handleDelete(record)">删除</a-button>
                        </div>
                    </template>
                </template>
            </a-table>
        </div>
    </div>
    <AddOrEditFarmer v-model:open="open" :edit-data="editingUser" @close="closeDialog" @success="fetchTableData" />
</template>

<script setup lang="ts">
import { getFarmerInformations } from '@/services/farmerInformation'
import AddOrEditFarmer from './components/AddOrEditFarmer.vue'
import dayjs from 'dayjs'

interface ISearchParams {
    name: string
    createDate: string
    page: number
    pageSize: number
}

interface IPagination {
    total: number
    current: number
    pageSize: number
    pageSizeOptions: string[]
}

const searchMap = ref<ISearchParams>({
    name: '',
    createDate: '',
    page: 1,
    pageSize: 10
})

const pagination = reactive<IPagination>({
    total: 0,
    current: 1,
    pageSize: 10,
    pageSizeOptions: ['5', '7', '10']
})

const open = ref(false)
const loading = ref(false)
const tableData = ref([])
const editingUser = ref<any>(null)

const columns = [
    {
        title: '账号',
        dataIndex: 'code',
        key: 'code'
    },
    {
        title: '农户姓名',
        dataIndex: 'name',
        key: 'name'
    },
    {
        title: '昵称',
        dataIndex: 'nickname',
        key: 'nickname'
    },
    {
        title: '性别',
        dataIndex: 'gender',
        key: 'gender',
        customRender: ({ text }: { text: string }) => (text === 'Y' ? '男' : '女')
    },
    {
        title: '身份证号',
        dataIndex: 'idNo',
        key: 'idNo'
    },
    {
        title: '手机号码',
        dataIndex: 'cellphone',
        key: 'cellphone'
    },
    {
        title: '固定电话',
        dataIndex: 'telephone',
        key: 'telephone'
    },
    {
        title: '邮箱',
        dataIndex: 'emailAddress',
        key: 'emailAddress'
    },
    {
        title: '微信',
        dataIndex: 'wechat',
        key: 'wechat'
    },
    {
        title: 'QQ',
        dataIndex: 'qq',
        key: 'qq'
    },
    {
        title: '出生日期',
        dataIndex: 'dateOfBirth',
        key: 'dateOfBirth',
        customRender: ({ text }: { text: string }) => (text ? dayjs(text).format('YYYY-MM-DD') : '-')
    },
    {
        title: '创建时间',
        dataIndex: 'createDate',
        key: 'createDate',
        customRender: ({ text }: { text: string }) => (text ? dayjs(text).format('YYYY-MM-DD HH:mm:ss') : '-')
    },
    {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        customRender: ({ text }: { text: string }) => (text === '1' ? '启用' : '禁用')
    },
    {
        title: '操作',
        key: 'action',
        width: 200,
        fixed: 'right'
    }
]

const handleSearch = () => {
    fetchTableData()
}

const closeDialog = () => {
    open.value = false
    editingUser.value = {}
    fetchTableData()
}

const fetchTableData = async () => {
    open.value = false
    editingUser.value = {}
    loading.value = true
    try {
        const res = await getFarmerInformations(searchMap.value)
        if (res.code === 20000) {
            tableData.value = res.data.records || []
            pagination.total = res.data.total
            pagination.current = res.data.current
            pagination.pageSize = res.data.size
        }
    } finally {
        loading.value = false
    }
}

const handleTableChange = (pag: any) => {
    searchMap.value.page = pag.current
    searchMap.value.pageSize = pag.pageSize
    fetchTableData()
}

const handleEdit = (record: any) => {
    editingUser.value = record

    open.value = true
}

const handleDelete = (record: any) => {}

onMounted(() => {
    fetchTableData()
})
</script>

<style scoped lang="scss">
.form-area {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left-section {
        display: flex;
        align-items: center;
    }

    .ant-input-affix-wrapper {
        width: 200px;
    }
}
</style>
