<template>
    <a-modal
        :title="isEdit ? '修改产品' : '新增产品'"
        :open="props.open"
        width="800px"
        @ok="handleSubmit"
        @cancel="emit('close')"
    >
        <a-form ref="formRef" :model="formState" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-form-item label="产品名称" name="productName">
                <a-input v-model:value="formState.productName" placeholder="请输入产品名称" />
            </a-form-item>
            <a-form-item label="数量" name="count">
                <a-input-number v-model:value="formState.count" placeholder="请输入数量" style="width: 100%" />
            </a-form-item>
            <a-form-item label="数量单位" name="countUnit">
                <a-select v-model:value="formState.countUnit" placeholder="请选择数量单位">
                    <a-select-option value="个">个</a-select-option>
                    <a-select-option value="白">白</a-select-option>
                    <a-select-option value="千">千</a-select-option>
                    <a-select-option value="万">万</a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="价格" name="price">
                <a-input-number v-model:value="formState.price" placeholder="请输入价格" style="width: 100%" />
            </a-form-item>
            <a-form-item label="价格单位" name="priceUnit">
                <a-select v-model:value="formState.priceUnit" placeholder="请选择价格单位">
                    <a-select-option value="元">元</a-select-option>
                    <a-select-option value="千元">千元</a-select-option>
                    <a-select-option value="万元">万元</a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="规格" name="spec">
                <a-select v-model:value="formState.spec" placeholder="请选择规格">
                    <a-select-option value="小">小</a-select-option>
                    <a-select-option value="中">中</a-select-option>
                    <a-select-option value="大">大</a-select-option>
                    <a-select-option value="特大">特大</a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="产品尺寸" name="productSize">
                <a-input-number
                    v-model:value="formState.productSize"
                    placeholder="请输入产品尺寸"
                    style="width: 100%"
                />
            </a-form-item>
            <a-form-item label="产品颜色" name="productColor">
                <a-input v-model:value="formState.productColor" placeholder="请输入产品颜色" />
            </a-form-item>
            <a-form-item label="产品部位" name="productPart">
                <a-input v-model:value="formState.productPart" placeholder="请输入产品部位" />
            </a-form-item>
            <a-form-item label="包装方式" name="packageMethod">
                <a-select v-model:value="formState.packageMethod" placeholder="请选择包装方式">
                    <a-select-option value="散装">散装</a-select-option>
                    <a-select-option value="真空">真空</a-select-option>
                    <a-select-option value="盒装">盒装</a-select-option>
                    <a-select-option value="袋装">袋装</a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="存储条件" name="storage">
                <a-select v-model:value="formState.storage" placeholder="请选择存储条件">
                    <a-select-option value="常温">常温</a-select-option>
                    <a-select-option value="冷藏">冷藏</a-select-option>
                    <a-select-option value="冷冻">冷冻</a-select-option>
                    <a-select-option value="避光">避光</a-select-option>
                    <a-select-option value="阴凉">阴凉</a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="质量等级" name="qualityCategory">
                <a-select v-model:value="formState.qualityCategory" placeholder="请选择质量等级">
                    <a-select-option value="优质">优质</a-select-option>
                    <a-select-option value="一级">一级</a-select-option>
                    <a-select-option value="二级">二级</a-select-option>
                    <a-select-option value="三级">三级</a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="产品描述" name="productDesc">
                <a-textarea v-model:value="formState.productDesc" placeholder="请输入产品描述" />
            </a-form-item>
            <a-form-item label="备注" name="remark">
                <a-textarea v-model:value="formState.remark" placeholder="请输入备注" />
            </a-form-item>
            <a-form-item label="状态" name="status">
                <a-select v-model:value="formState.status" placeholder="请选择状态">
                    <a-select-option value="0">现售</a-select-option>
                    <a-select-option value="1">限售</a-select-option>
                    <a-select-option value="2">预售</a-select-option>
                    <a-select-option value="3">售完</a-select-option>
                    <a-select-option value="4">已下架</a-select-option>
                </a-select>
            </a-form-item>
        </a-form>
    </a-modal>
</template>

<script setup lang="ts">
import { type FormInstance } from 'ant-design-vue'
import { message } from 'ant-design-vue'
import type { UnwrapRef } from 'vue'
import type { Rule } from 'ant-design-vue/es/form'

defineOptions({
    name: 'AddOrEditProduct'
})

const props = defineProps({
    open: Boolean,
    editData: {
        type: Object,
        default: null
    }
})

const emit = defineEmits(['success', 'close'])

const labelCol = { span: 6 }
const wrapperCol = { span: 16 }

interface FormState {
    productName: string
    count: number
    countUnit: string
    price: number
    priceUnit: string
    spec: string
    productSize: number
    productColor: string
    productPart: string
    packageMethod: string
    storage: string
    qualityCategory: string
    productDesc: string
    remark: string
    status: string
    farmId?: string
    farmerId?: string
    handler?: string
}

const initialFormState: FormState = {
    productName: '',
    count: 0,
    countUnit: '个',
    price: 0,
    priceUnit: '元',
    spec: '中',
    productSize: 0,
    productColor: '',
    productPart: '',
    packageMethod: '散装',
    storage: '常温',
    qualityCategory: '一级',
    productDesc: '',
    remark: '',
    status: '0'
}

const formRef = ref<FormInstance>()
const formState: UnwrapRef<FormState> = reactive({
    ...initialFormState
})

const rules = {
    productName: [{ required: true, message: '请输入产品名称' }],
    count: [{ required: true, message: '请输入产品数量' }],
    countUnit: [{ required: true, message: '请选择数量单位' }],
    price: [{ required: true, message: '请输入价格' }],
    priceUnit: [{ required: true, message: '请选择价格单位' }],
    status: [{ required: true, message: '请选择状态' }]
}

const handleSubmit = () => {
    formRef.value?.validate().then(async () => {
        try {
            const data = toRaw(formState)
            let res
            if (isEdit.value) {
                console.log('编辑产品', data)
                // res = await updateProduct(data)
            } else {
                // res = await addProduct(data)
            }
            emit('success')
            message.success('操作成功')
        } catch (error) {
            console.log('error', error)
        }
    })
}

const isEdit = computed(() => {
    return props.editData && Object.keys(props.editData).length > 0
})

const resetForm = () => {
    formRef.value?.resetFields()
    Object.assign(formState, initialFormState)
}

watch(
    () => props.open,
    newVal => {
        if (newVal) {
            if (isEdit.value) {
                Object.assign(formState, props.editData)
            }
        } else {
            resetForm()
        }
    }
)
</script>

<style scoped>
.ant-form-item {
    margin-bottom: 24px;
}
</style>
