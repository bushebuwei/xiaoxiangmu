<template>
    <div class="page-container">
        <div class="form-area">
            <div class="left-section">
                <div class="forms">
                    <a-input v-model:value="searchMap.productName" allowClear placeholder="请输入产品名称" />
                    <a-date-picker
                        v-model:value="searchMap.createDate"
                        value-format="YYYY-MM-DD"
                        placeholder="请选择创建日期"
                    />
                    <a-button type="primary" @click="handleSearch">查询</a-button>
                </div>
            </div>
            <a-button type="primary" @click="open = true">新增</a-button>
        </div>
        <div class="content-area">
            <a-table
                :columns="columns"
                :row-key="(record:any) => record.id"
                :data-source="tableData"
                :pagination="{
                    total: pagination.total,
                    current: pagination.current,
                    pageSize: pagination.pageSize,
                    pageSizeOptions: pagination.pageSizeOptions,
                    showSizeChanger: true
                }"
                :loading="loading"
                @change="handleTableChange"
            >
                <template #bodyCell="{ column, record }">
                    <template v-if="column.dataIndex === 'operation'">
                        <div>
                            <a-button type="primary" size="small" @click="handleProductEdit(record)">编辑</a-button>
                            <a-button danger type="text" size="small" @click="handleProductDelete(record)">
                                删除
                            </a-button>
                        </div>
                    </template>
                </template>
            </a-table>
        </div>
    </div>
    <add-or-edit-product :open="open" :edit-data="editingProduct" @close="closeDialog" />
</template>

<script lang="ts" setup>
defineOptions({
    name: 'FarmerProductManage'
})

import { ref, reactive, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import AddOrEditProduct from './components/AddOrEditProduct.vue'
// 假设这些是您需要导入的服务
import { getFarmerProducts } from '@/services/farmerProduct'

interface ISearchParams {
    productName: string
    createDate: string
    page: number
    pageSize: number
}

interface IPagination {
    total: number
    current: number
    pageSize: number
    pageSizeOptions: string[]
}

const open = ref(false)
const tableData = ref([])
const loading = ref(false)
const editingProduct = ref({})

const searchMap = ref<ISearchParams>({
    productName: '',
    createDate: '',
    page: 1,
    pageSize: 10
})

const pagination = reactive<IPagination>({
    total: 0,
    current: 1,
    pageSize: 10,
    pageSizeOptions: ['5', '7', '10']
})

const columns = [
    {
        title: '产品名称',
        dataIndex: 'productName',
        sorter: true
    },
    {
        title: '产品描述',
        dataIndex: 'productDesc'
    },
    {
        title: '价格',
        dataIndex: 'price',
        customRender: ({ text, record }: { text: number; record: any }) => {
            return `${text} ${record.priceUnit}`
        }
    },
    {
        title: '数量',
        dataIndex: 'count',
        customRender: ({ text, record }: { text: number; record: any }) => {
            return `${text} ${record.countUnit}`
        }
    },
    {
        title: '规格',
        dataIndex: 'spec'
    },
    {
        title: '包装方式',
        dataIndex: 'packageMethod'
    },
    {
        title: '储存条件',
        dataIndex: 'storage'
    },
    {
        title: '质量等级',
        dataIndex: 'qualityCategory'
    },
    {
        title: '创建时间',
        dataIndex: 'createDate',
        customRender: ({ text }: { text: string | null }) => {
            if (!text) return ''
            const date = new Date(text)
            return date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })
        }
    },
    {
        title: '操作',
        dataIndex: 'operation'
    }
]

const handleSearch = async () => {
    loading.value = true
    try {
        const res = await getFarmerProducts(searchMap.value)
        if (res.code === 20000) {
            tableData.value = res.data.records
            pagination.total = res.data.total
            pagination.current = res.data.current
            pagination.pageSize = res.data.size
        } else {
            message.error(res.message)
        }
    } finally {
        loading.value = false
    }
}

const closeDialog = () => {
    open.value = false
    editingProduct.value = {}
    handleSearch()
}

const handleTableChange = (pagination: any) => {
    searchMap.value.page = pagination.current
    searchMap.value.pageSize = pagination.pageSize
    handleSearch()
}

const handleProductEdit = (record: any) => {
    editingProduct.value = record
    open.value = true
}

const handleProductDelete = (record: any) => {
    // deleteProductById(record.id).then(res => {
    //     if (res.code === 20000) {
    //         message.success('删除成功')
    //         handleSearch()
    //     }
    // })
}

onMounted(() => {
    handleSearch()
})
</script>

<style scoped lang="scss">
.form-area {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left-section {
        display: flex;
        align-items: center;
    }

    .ant-input-affix-wrapper {
        width: 200px;
    }
}
</style>
