<template>
    <a-drawer
        :open="props.orderDetailOpen"
        size="large"
        @update:open="$emit('update:orderDetailOpen', $event)"
        title="订单详情"
        placement="right"
        @after-open-change="afterOpenChange"
    >
        <a-descriptions bordered>
            <a-descriptions-item label="订单编号">{{ orderDetail.orderId }}</a-descriptions-item>
            <a-descriptions-item label="序号">{{ orderDetail.seqNo }}</a-descriptions-item>
            <a-descriptions-item label="商品ID">{{ orderDetail.fprodId }}</a-descriptions-item>
            <a-descriptions-item label="商品名称">{{ orderDetail.fprodName }}</a-descriptions-item>
            <a-descriptions-item label="商品描述" :span="2">{{ orderDetail.fprodDesc }}</a-descriptions-item>
            <a-descriptions-item label="订单数量">
                {{ orderDetail.orderQty }}{{ orderDetail.orderUnit }}
            </a-descriptions-item>
            <a-descriptions-item label="单价">{{ orderDetail.cost }}{{ orderDetail.costUnit }}</a-descriptions-item>
            <a-descriptions-item label="总价">
                {{ orderDetail.cost * orderDetail.orderQty }}{{ orderDetail.costUnit }}
            </a-descriptions-item>
            <a-descriptions-item label="收货日期" :span="2">
                {{ formatDate(orderDetail.receivedDate) }}
            </a-descriptions-item>
            <a-descriptions-item label="收货数量">
                {{ orderDetail.receivedQty ? orderDetail.receivedQty : '-' }}{{ orderDetail.orderUnit }}
            </a-descriptions-item>
            <a-descriptions-item label="退货日期" :span="2">
                {{ formatDate(orderDetail.rejectDate) }}
            </a-descriptions-item>
            <a-descriptions-item label="退货数量">
                {{ orderDetail.rejectQty ? orderDetail.rejectQty : '-' }}{{ orderDetail.orderUnit }}
            </a-descriptions-item>
            <a-descriptions-item label="退货状态">
                {{
                    orderDetail.returnStatus
                        ? returnStatusMap[orderDetail.returnStatus as keyof typeof returnStatusMap]
                        : '-'
                }}
            </a-descriptions-item>
        </a-descriptions>
    </a-drawer>
</template>

<script lang="ts" setup>
import { getOrderDetailByOrderId } from '@/services/orderDetail'

const props = defineProps<{
    editingOrderId: string
    orderDetailOpen: boolean
}>()

const orderDetail = ref({
    orderId: '',
    seqNo: 0,
    fprodId: '',
    fprodName: '',
    fprodDesc: '',
    orderQty: 0,
    orderUnit: '',
    cost: 0,
    costUnit: '',
    receivedDate: '',
    receivedQty: 0,
    rejectDate: '',
    rejectQty: 0,
    returnStatus: '0',
    remarks: ''
})

const returnStatusMap = {
    '0': '未退货',
    '1': '已退货'
    // 根据实际情况添加其他状态
}

const formatDate = (dateString: string) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleString()
}

const afterOpenChange = (bool: boolean) => {
    // console.log('open', bool)
}

watch(
    () => props.orderDetailOpen,
    newVal => {
        if (newVal) {
            getOrderDetailByOrderId(props.editingOrderId).then(res => {
                orderDetail.value = res.data
            })
        }
    }
)
</script>
