<template>
    <a-modal
        :open="open"
        :maskClosable="false"
        width="600px"
        :title="isEdit ? '编辑订单' : '新增订单'"
        @cancel="emit('close')"
        @ok="onSubmit"
    >
        <a-form ref="formRef" :model="form" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-form-item label="客户名字" name="customerName">
                <a-select v-model:value="form.custId" :options="customerOptions" />
            </a-form-item>
            <a-form-item label="订单状态" name="orderStatus">
                <a-select v-model:value="form.orderStatus" :options="orderStatusOptions" />
            </a-form-item>
            <a-form-item label="地址信息" name="addrId">
                <AreaCascade v-model:addrId="form.addrId" />
            </a-form-item>
            <a-form-item label="支付方式" name="payMethod">
                <a-select v-model:value="form.payMethod" :options="paymentMethodOptions" />
            </a-form-item>
            <a-form-item label="物流状态" name="logStatus">
                <a-select v-model:value="form.logStatus" :options="logisticsStatusOptions" />
            </a-form-item>
            <a-form-item label="签收人" name="signatory">
                <a-input v-model:value="form.signatory" />
            </a-form-item>
            <a-form-item label="农产品名称" name="productName">
                <a-select v-model:value="form.productId" :options="farmerProductNameOptions" />
            </a-form-item>
            <a-form-item label="农产品订购数量" name="productQuantity">
                <a-input-number min="0" v-model:value="form.productQuantity" />
            </a-form-item>
            <a-form-item label="单价" name="unitPrice">
                <a-input-number min="0" v-model:value="form.unitPrice" />
            </a-form-item>
        </a-form>
    </a-modal>
</template>

<script lang="ts" setup>
import AreaCascade from '@/components/AreaCascade.vue'
import { getFarmerProductNames } from '@/services/farmerProduct'
defineOptions({
    name: 'AddOrEditOrder'
})
const props = defineProps({
    open: Boolean,
    editData: {
        type: Object,
        default: null
    }
})
const emit = defineEmits(['close'])
import type { UnwrapRef } from 'vue'
import type { Rule } from 'ant-design-vue/es/form'
import { addOrder } from '@/services/orderHead'
import { message } from 'ant-design-vue'
import { getCustNames } from '@/services/custInformation'

interface FormState {
    custId: string
    orderStatus: string
    addrId: any
    payMethod: string
    logStatus: string
    signatory: string
    productId: string
    productQuantity: string
    unitPrice: string
}
const formRef = ref()
const labelCol = { span: 6 }
const wrapperCol = { span: 16 }

const initialFormState = {
    custId: '',
    orderStatus: '',
    addrId: [],
    payMethod: '',
    logStatus: '',
    signatory: '',
    productId: '',
    productQuantity: '1',
    unitPrice: '元'
}

const form: UnwrapRef<FormState> = reactive({
    ...initialFormState
})
const rules: Record<string, Rule[]> = {}
const onSubmit = () => {
    formRef.value
        .validate()
        .then(async () => {
            const data = toRaw(form)
            data.addrId = data.addrId.join(',')
            let res
            console.log(data)

            if (isEdit.value) {
                // res = await editOrder(data)
            } else {
                res = await addOrder(data)
            }

            if (res?.code === 20000) {
                message.success(res.data)
                emit('close')
                formRef.value.resetFields()
            }
        })
        .catch((error: any) => {
            console.log('error', error)
        })
}
const resetForm = () => {
    formRef.value.resetFields()
    Object.assign(form, initialFormState)
}

const paymentMethodOptions = ref([
    { label: '微信', value: '0' },
    { label: '银行卡', value: '1' }
])

const logisticsStatusOptions = ref([
    { label: '未发货', value: '0' },
    { label: '已发货', value: '1' },
    { label: '正在运输中', value: '2' },
    { label: '已送达', value: '3' },
    { label: '已接收', value: '4' }
])

const farmerProductNameOptions = ref([])

const isEdit = computed(() => {
    return props.editData && Object.keys(props.editData).length > 0
})

const customerOptions = ref([])

const orderStatusOptions = ref([
    { label: '已支付', value: '1' },
    { label: '已接单', value: '2' },
    { label: '已发货', value: '3' },
    { label: '已签收', value: '4' }
])

watch(
    () => props.open,
    newVal => {
        if (newVal) {
            getCustNames().then(res => {
                customerOptions.value = res.data.map((cust: any) => ({
                    label: cust.name,
                    value: cust.custId
                }))
            })
            getFarmerProductNames().then(res => {
                farmerProductNameOptions.value = res.data.map((product: any) => ({
                    label: product.name,
                    value: product.farmerProductId
                }))
            })
            if (isEdit.value) {
                Object.assign(form, props.editData)
            }
        } else {
            resetForm()
        }
    }
)
</script>
