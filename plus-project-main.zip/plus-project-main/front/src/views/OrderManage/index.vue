<template>
    <div class="page-container">
        <div class="form-area">
            <div class="left-section">
                <div class="forms">
                    <a-input v-model:value="searchMap.orderId" allowClear placeholder="请输入订单编号" />
                    <a-date-picker
                        v-model:value="searchMap.orderDate"
                        value-format="YYYY-MM-DD"
                        placeholder="请选择下单日期"
                    />
                    <a-button type="primary" @click="handleSearch">查询</a-button>
                </div>
            </div>
            <a-button type="primary" @click="open = true">新增订单</a-button>
        </div>
        <div class="content-area">
            <a-table
                :columns="columns"
                :row-key="(record:any) => record.id"
                :data-source="tableData"
                :pagination="{
                    total: pagination.total,
                    current: pagination.current,
                    pageSize: pagination.pageSize,
                    pageSizeOptions: pagination.pageSizeOptions,
                    showSizeChanger: true
                }"
                :loading="loading"
                :custom-row="
                    (record:any) => ({
                        onClick: () => handleDetailDrawer(record)
                    })
                "
                @change="handleTableChange"
            >
                <template #bodyCell="{ column, record }">
                    <template v-if="column.key === 'action'">
                        <div>
                            <a-button type="primary" size="small" @click.stop="handleEdit(record)">编辑</a-button>
                            <a-button danger type="text" size="small" @click="handleDelete(record)">删除</a-button>
                        </div>
                    </template>
                </template>
            </a-table>
        </div>
    </div>
    <OrderDetailDrawer
        :editingOrderId="editingOrderId"
        :orderDetailOpen="orderDetailOpen"
        @update:orderDetailOpen="orderDetailOpen = $event"
    />
    <AddOrEditOrder v-model:open="open" :edit-data="editingOrder" @close="closeDialog" @success="fetchTableData" />
</template>

<script setup lang="ts">
import { getOrderHeads } from '@/services/orderHead'
import OrderDetailDrawer from './components/OrderDetailDrawer.vue'
import AddOrEditOrder from './components/AddOrEditOrder.vue'
import dayjs from 'dayjs'
import { Tag } from 'ant-design-vue'
import { h, resolveComponent } from 'vue'

interface ISearchParams {
    orderId?: string
    orderDate?: string
    page: number
    pageSize: number
}

interface IPagination {
    total: number
    current: number
    pageSize: number
    pageSizeOptions: string[]
}

const searchMap = ref<ISearchParams>({
    orderId: '',
    orderDate: '',
    page: 1,
    pageSize: 10
})

const pagination = reactive<IPagination>({
    total: 0,
    current: 1,
    pageSize: 10,
    pageSizeOptions: ['5', '7', '10']
})

const open = ref(false)
const orderDetailOpen = ref(false)
const loading = ref(false)
const tableData = ref([])
const editingOrderId = ref<string>('')

const editingOrder = ref<any>({})

const columns = [
    {
        title: '订单编号',
        dataIndex: 'orderId',
        key: 'orderId'
    },
    {
        title: '客户名称',
        dataIndex: 'custName',
        key: 'custName'
    },
    {
        title: '支付方式',
        dataIndex: 'payMethod',
        key: 'payMethod',
        customRender: ({ text }: { text: string }) => {
            const payMethodMap: Record<string, string> = {
                '0': '微信',
                '1': '银行卡'
            }
            return payMethodMap[text] || '-'
        }
    },
    {
        title: '订单状态',
        dataIndex: 'orderStatus',
        key: 'orderStatus',
        customRender: ({ text }: { text: string }) => {
            const statusMap: Record<string, string> = {
                '1': '已支付',
                '2': '已接单',
                '3': '已发货',
                '4': '已签收'
            }
            const colorMap: Record<string, string> = {
                '1': 'blue',
                '2': 'processing',
                '3': 'warning',
                '4': 'success'
            }
            return h(Tag, { color: colorMap[text] }, () => statusMap[text] || '-')
        }
    },
    {
        title: '物流状态',
        dataIndex: 'logStatus',
        key: 'logStatus',
        customRender: ({ text }: { text: string }) => {
            const logStatusMap: Record<string, string> = {
                '1': '待发货',
                '2': '已发货',
                '3': '运输中',
                '4': '已送达',
                '5': '已签收'
            }
            return logStatusMap[text] || '-'
        }
    },
    {
        title: '下单时间',
        dataIndex: 'orderDate',
        key: 'orderDate',
        customRender: ({ text }: { text: string }) => (text ? dayjs(text).format('YYYY-MM-DD HH:mm:ss') : '-')
    },
    {
        title: '支付时间',
        dataIndex: 'payDate',
        key: 'payDate',
        customRender: ({ text }: { text: string }) => (text ? dayjs(text).format('YYYY-MM-DD HH:mm:ss') : '-')
    },
    {
        title: '发货时间',
        dataIndex: 'deliverDate',
        key: 'deliverDate',
        customRender: ({ text }: { text: string }) => (text ? dayjs(text).format('YYYY-MM-DD HH:mm:ss') : '-')
    },
    {
        title: '签收人',
        dataIndex: 'signatory',
        key: 'signatory'
    },
    {
        title: '签收时间',
        dataIndex: 'signingDate',
        key: 'signingDate',
        customRender: ({ text }: { text: string }) => (text ? dayjs(text).format('YYYY-MM-DD HH:mm:ss') : '-')
    },
    {
        title: '操作',
        key: 'action',
        width: 200,
        fixed: 'right'
    }
]

const handleSearch = () => {
    fetchTableData()
}

const closeDialog = () => {
    open.value = false
    editingOrderId.value = ''
    fetchTableData()
}

const fetchTableData = async () => {
    open.value = false
    editingOrderId.value = ''
    loading.value = true
    try {
        const res = await getOrderHeads(searchMap.value)
        if (res.code === 20000) {
            tableData.value = res.data.records || []
            pagination.total = res.data.total
            pagination.current = res.data.current
            pagination.pageSize = res.data.size
        }
    } finally {
        loading.value = false
    }
}

const handleTableChange = (pag: any) => {
    searchMap.value.page = pag.current
    searchMap.value.pageSize = pag.pageSize
    fetchTableData()
}

const handleDetailDrawer = (record: any) => {
    orderDetailOpen.value = true
    editingOrderId.value = record.orderId
}

const handleEdit = (record: any) => {
    open.value = true
}

const handleDelete = (record: any) => {}

onMounted(() => {
    fetchTableData()
})
</script>

<style scoped lang="scss">
.form-area {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left-section {
        display: flex;
        align-items: center;
    }

    .ant-input-affix-wrapper {
        width: 200px;
    }
}
:deep(.ant-table-tbody > tr) {
    cursor: pointer;
}
</style>
