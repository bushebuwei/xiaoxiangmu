<template>
    <div class="page-container">
        <div class="form-area">
            <div class="left-section">
                <div class="forms">
                    <a-input v-model:value="searchMap.inviteName" allowClear placeholder="请输入查询的产户名称" />
                    <a-date-picker
                        v-model:value="searchMap.inviteTime"
                        value-format="YYYY-MM-DD"
                        placeholder="请选择创建日期"
                    />
                    <a-button type="primary" @click="handleSearch">查询</a-button>
                </div>
            </div>
            <a-button type="primary" @click="handleInitiateSettlement">发起结算</a-button>
        </div>
        <div class="content-area">
            <a-table
                :columns="columns"
                :row-key="(record:any) => record.id"
                :data-source="tableData"
                :pagination="{
                    total: pagination.total,
                    current: pagination.current,
                    pageSize: pagination.pageSize,
                    pageSizeOptions: pagination.pageSizeOptions,
                    showSizeChanger: true
                }"
                :loading="loading"
                @change="handleTableChange"
            >
                <template #bodyCell="{ column, record }">
                    <template v-if="column.key === 'action'">
                        <div>
                            <a-button type="primary" size="small" @click="handleView(record)">查看</a-button>
                        </div>
                    </template>
                </template>
            </a-table>
        </div>
    </div>
    <StartSettlement v-model:open="open" @close="closeDialog" />
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import StartSettlement from './components/StartSettlement.vue'
import { getSettlementInvites } from '@/services/settlementInvite'
import dayjs from 'dayjs'

interface ISearchParams {
    inviteName: string
    inviteTime: string
    page: number
    pageSize: number
}

interface IPagination {
    total: number
    current: number
    pageSize: number
    pageSizeOptions: string[]
}

const searchMap = ref<ISearchParams>({
    inviteName: '',
    inviteTime: '',
    page: 1,
    pageSize: 5
})

const pagination = reactive<IPagination>({
    total: 0,
    current: 1,
    pageSize: 5,
    pageSizeOptions: ['5', '7', '10']
})

const loading = ref(false)
const tableData = ref([])
const open = ref(false)

const closeDialog = () => {
    open.value = false
}

const columns = [
    {
        title: '邀请名称',
        dataIndex: 'inviteName',
        key: 'inviteName'
    },
    {
        title: '结算周期',
        dataIndex: 'settlementCycle',
        key: 'settlementCycle',
        customRender: ({ text }: { text: string }) => {
            const cycleMap: any = {
                m: '月度结算',
                q: '季度结算',
                y: '年度结算'
            }
            return cycleMap[text] || text
        }
    },
    {
        title: '结算方式',
        dataIndex: 'settlementType',
        key: 'settlementType',
        customRender: ({ text }: { text: string }) => {
            const typeMap: any = {
                '1': '现金结算',
                '2': '银行转账',
                '3': '其他'
            }
            return typeMap[text] || text
        }
    },
    {
        title: '发起方',
        dataIndex: 'initiator',
        key: 'initiator',
        customRender: ({ text }: { text: string }) => (text === '1' ? '平台' : text)
    },
    {
        title: '接受方',
        dataIndex: 'recipient',
        key: 'recipient'
    },
    {
        title: '确定时间',
        dataIndex: 'confirmTime',
        key: 'confirmTime',
        customRender: ({ text }: { text: string }) => (text ? dayjs(text).format('YYYY-MM-DD HH:mm:ss') : '-')
    },
    {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        customRender: ({ text }: { text: string }) => {
            const statusMap: any = {
                '0': '待确认',
                '1': '已确认',
                '2': '已拒绝'
            }
            return statusMap[text] || text
        }
    },
    {
        title: '备注',
        dataIndex: 'remark',
        key: 'remark'
    }
]

const handleSearch = () => {
    fetchTableData()
}

const handleInitiateSettlement = () => {
    open.value = true
}

const handleView = (record: any) => {
    // 实现查看详情的逻辑
}

const fetchTableData = async () => {
    loading.value = true
    try {
        // 实现获取数据的接口调用
        const res = await getSettlementInvites(searchMap.value)
        if (res.code === 20000) {
            tableData.value = res.data.records || []
            pagination.total = res.data.total
            pagination.current = res.data.current
            pagination.pageSize = res.data.size
        }
    } finally {
        loading.value = false
    }
}

const handleTableChange = (pag: any) => {
    searchMap.value.page = pag.current
    searchMap.value.pageSize = pag.pageSize
    fetchTableData()
}

onMounted(() => {
    fetchTableData()
})
</script>

<style scoped lang="scss">
.form-area {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left-section {
        display: flex;
        align-items: center;
    }

    .ant-input-affix-wrapper {
        width: 200px;
    }
}
</style>
