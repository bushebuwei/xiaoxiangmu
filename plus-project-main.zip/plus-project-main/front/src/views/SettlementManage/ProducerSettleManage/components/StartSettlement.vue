<template>
    <a-modal :open="open" :maskClosable="false" width="600px" title="发起结算" @cancel="emit('close')" @ok="onSubmit">
        <a-form ref="formRef" :model="form" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-form-item label="邀请名称" name="inviteName">
                <a-input v-model:value="form.inviteName" />
            </a-form-item>
            <a-form-item label="结算周期" name="settlementCycle">
                <a-select v-model:value="form.settlementCycle" :options="periodOptions" />
            </a-form-item>
            <a-form-item label="结算方式" name="settlementType">
                <a-select v-model:value="form.settlementType" :options="methodOptions" />
            </a-form-item>
            <a-form-item label="发起方" name="initiator">
                <a-select v-model:value="form.initiator" :options="initiatorOptions" />
            </a-form-item>
            <a-form-item label="接受方" name="recipient">
                <a-select v-model:value="form.recipient" :options="receiverOptions" />
            </a-form-item>
            <a-form-item label="确定时间" name="confirmTime">
                <a-date-picker v-model:value="form.confirmTime" />
            </a-form-item>
            <a-form-item label="状态" name="status">
                <a-select v-model:value="form.status" :options="statusOptions" />
            </a-form-item>
            <a-form-item label="备注" name="remark">
                <a-textarea v-model:value="form.remark" />
            </a-form-item>
        </a-form>
    </a-modal>
</template>

<script lang="ts" setup>
defineOptions({
    name: 'StartSettlement'
})

const props = defineProps({
    open: Boolean
})

const emit = defineEmits(['close'])

import type { UnwrapRef } from 'vue'
import type { Rule } from 'ant-design-vue/es/form'
import { message } from 'ant-design-vue'
import { getFarmerInformations } from '@/services/farmerInformation'
import { startSettlement } from '@/services/settlementInvite'
import dayjs from 'dayjs'

interface FormState {
    inviteName: string
    settlementCycle: string
    settlementType: string
    initiator: string
    recipient: string
    confirmTime: any
    status: string
    remark: string
}

const formRef = ref()
const labelCol = { span: 6 }
const wrapperCol = { span: 16 }

const initialFormState = {
    inviteName: '',
    settlementCycle: '',
    settlementType: '',
    initiator: '1',
    recipient: '',
    confirmTime: null,
    status: '0',
    remark: ''
}

const form: UnwrapRef<FormState> = reactive({
    ...initialFormState
})

const rules: Record<string, Rule[]> = {
    inviteName: [{ required: true, message: '请输入邀请名称' }],
    settlementCycle: [{ required: true, message: '请选择结算周期' }],
    settlementType: [{ required: true, message: '请选择结算方式' }],
    initiator: [{ required: true, message: '请选择发起方' }],
    recipient: [{ required: true, message: '请选择接受方' }],
    confirmTime: [{ required: true, message: '请选择确定时间' }]
}

const periodOptions = ref([
    { label: '月度结算', value: 'm' },
    { label: '季度结算', value: 'q' },
    { label: '年度结算', value: 'y' }
])

const methodOptions = ref([
    { label: '现金结算', value: '1' },
    { label: '银行转账', value: '2' },
    { label: '其他', value: '3' }
])

const statusOptions = ref([
    { label: '待确认', value: '0' },
    { label: '已确认', value: '1' },
    { label: '已拒绝', value: '2' }
])

const initiatorOptions = ref([{ label: '平台', value: '1' }])
const receiverOptions = ref([])

const onSubmit = () => {
    formRef.value
        .validate()
        .then(async () => {
            const res = await startSettlement(form)

            if (res?.code === 20000) {
                message.success('发起结算成功')
                emit('close')
                formRef.value.resetFields()
            }
        })
        .catch((error: any) => {
            console.log('error', error)
        })
}

const resetForm = () => {
    formRef.value.resetFields()
    Object.assign(form, initialFormState)
}

const init = async () => {
    const res = await getFarmerInformations({})
    receiverOptions.value = res.data.records.map((item: any) => ({
        label: item.nickname,
        value: item.id
    }))
}
onMounted(() => {
    init()
})
</script>
