<template>
    <a-modal
        :open="open"
        :maskClosable="false"
        width="600px"
        :title="isEdit ? '编辑用户' : '新增用户'"
        @cancel="emit('close')"
        @ok="onSubmit"
    >
        <a-form ref="formRef" :model="form" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-form-item label="用户名" name="userName">
                <a-input v-model:value="form.userName" :disabled="isEdit" />
            </a-form-item>
            <a-form-item label="密码" name="password">
                <a-input v-model:value="form.password" />
            </a-form-item>
            <!-- <a-form-item label="用户组" name="userGroup">
                <a-input v-model:value="form.userGroup" />
            </a-form-item> -->
            <a-form-item label="角色权限" name="roleId">
                <a-select v-model:value="form.roleIds" mode="multiple" :max-tag-count="3" :options="userRoleOptions" />
            </a-form-item>
            <!-- <a-form-item label="用户级别" required name="userLevel">
                <a-select v-model:value="form.userLevel" :options="userLevelOptions" />
            </a-form-item> -->
            <a-form-item label="所属单位" name="enterpriseCode">
                <a-select allowClear v-model:value="form.enterpriseCode" :options="enterpriseOptions" />
            </a-form-item>
            <!-- <a-form-item label="所属父角色" name="parentUserId">
                <a-select allowClear v-model:value="form.parentUserId" :options="parentUserOptions" />
            </a-form-item> -->
            <a-form-item label="最大登录数" name="maxCount">
                <a-input-number min="1" v-model:value="form.maxCount" />
            </a-form-item>
            <a-form-item label="消息管理员" name="mesManager">
                <a-radio-group v-model:value="form.msgManager">
                    <a-radio value="Y">是</a-radio>
                    <a-radio value="N">否</a-radio>
                </a-radio-group>
            </a-form-item>
        </a-form>
    </a-modal>
</template>

<script lang="ts" setup>
defineOptions({
    name: 'AddOrEditUser'
})
const props = defineProps({
    open: Boolean,
    editData: {
        type: Object,
        default: null
    },
    userRoleOptions: {
        type: Array,
        default: () => []
    },
    enterpriseOptions: {
        type: Array,
        default: () => []
    }
})
const emit = defineEmits(['close'])
import type { UnwrapRef } from 'vue'
import type { Rule } from 'ant-design-vue/es/form'
import { message } from 'ant-design-vue'
import { addUser, editUser } from '@/services/sysUser'

interface FormState {
    userName: string
    password: string
    // userLevel: string
    enterpriseCode: string
    // parentUserId: string
    roleIds: string[]
    maxCount: number
    msgManager: string
    // userGroup: string
}
const formRef = ref()
const labelCol = { span: 6 }
const wrapperCol = { span: 16 }

// 添加初始表单状态常量
const initialFormState = {
    userName: '',
    password: '',
    // userLevel: '',
    roleIds: [],
    enterpriseCode: '',
    // parentUserId: '',
    maxCount: 1,
    msgManager: 'Y'
    // userGroup: ''
}

const form: UnwrapRef<FormState> = reactive({
    ...initialFormState
})
const rules: Record<string, Rule[]> = {
    userName: [
        { required: true, message: '请输入用户名', trigger: 'change' },
        { min: 3, max: 10, message: '长度应为3到10', trigger: 'blur' }
    ],
    password: [{ required: true, message: '请输入密码', trigger: 'change' }]
    // userLevel: [{ required: true, message: '请选择用户级别', trigger: 'change' }]
}
const onSubmit = () => {
    formRef.value
        .validate()
        .then(async () => {
            const data = toRaw(form)
            const { roleIds, ...sysUser } = data
            const params = { roleIds, sysUser }

            let res
            if (isEdit.value) {
                // 编辑用户
                res = await editUser(params)
            } else {
                // 新增用户
                res = await addUser(params)
            }

            if (res.code === 20000) {
                message.success(res.data)
                emit('close')
                formRef.value.resetFields()
            }
        })
        .catch((error: any) => {
            console.log('error', error)
        })
}
const resetForm = () => {
    formRef.value.resetFields()
    Object.assign(form, initialFormState)
}

// const userLevelOptions = [
//     { value: '1', label: '管理员' },
//     { value: '2', label: '普通用户' }
// ]

const isEdit = computed(() => {
    return props.editData && Object.keys(props.editData).length > 0
})

watch(
    () => props.open,
    newVal => {
        if (newVal) {
            if (isEdit.value) {
                Object.assign(form, props.editData)
            }
        } else {
            resetForm()
        }
    }
)
</script>
