<template>
    <div class="page-container">
        <div class="form-area">
            <div class="left-section">
                <div class="forms">
                    <a-input v-model:value="searchMap.username" allowClear placeholder="请输入查询的角色名称" />
                    <a-date-picker
                        v-model:value="searchMap.createDate"
                        value-format="YYYY-MM-DD"
                        placeholder="请选择创建日期"
                    />
                    <a-button type="primary" @click="handleSearch">查询</a-button>
                </div>
            </div>
            <a-button type="primary" @click="open = true">新增</a-button>
        </div>
        <div class="content-area">
            <a-table
                :columns="columns"
                :row-key="(record:any) => record.id"
                :data-source="tableData"
                :pagination="{
                    total: pagination.total,
                    current: pagination.current,
                    pageSize: pagination.pageSize,
                    pageSizeOptions: pagination.pageSizeOptions,
                    showSizeChanger: true
                }"
                :loading="loading"
                @change="handleTableChange"
            >
                <template #bodyCell="{ column, record }">
                    <template v-if="column.dataIndex === 'operation'">
                        <div>
                            <a-button type="primary" size="small" @click="handleUserEdit(record)">编辑</a-button>
                            <a-button danger type="text" size="small" @click="handleUserDelete(record)">删除</a-button>
                        </div>
                    </template>
                </template>
            </a-table>
        </div>
    </div>
    <add-or-edit-user
        :open="open"
        :edit-data="editingUser"
        :user-role-options="userRoleOptions"
        :enterprise-options="enterpriseOptions"
        @close="closeDialog"
    />
</template>
<script lang="ts" setup>
defineOptions({
    name: 'UserManage'
})
import { deleteUserById, getUsers } from '@/services/sysUser'
import AddOrEditUser from './components/AddOrEditUser.vue'
import { message } from 'ant-design-vue'
import { getRoles } from '@/services/sysAuthorityRole'
import { getUserRoles } from '@/services/sysAuthorityUserRole'
import { getEnterprises } from '@/services/pubEnterprise'

interface ISearchParams {
    username: string
    createDate: string
    page: number
    pageSize: number
}
interface IPagination {
    total: number
    current: number
    pageSize: number
    pageSizeOptions: string[]
}
const open = ref(false)
const tableData = ref([])
const searchMap = ref<ISearchParams>({
    username: '',
    createDate: '',
    page: 1,
    pageSize: 10
})
const pagination = reactive<IPagination>({
    total: 0,
    current: 1,
    pageSize: 10,
    pageSizeOptions: ['5', '7', '10']
})

const closeDialog = () => {
    open.value = false
    editingUser.value = {}
    handleSearch()
}

const userRoleOptions = ref<any[]>([])

const userRoleList = ref<any[]>([])

const enterpriseOptions = ref<any[]>([])

const getUserRoleOptions = async () => {
    const res = await getRoles()
    userRoleOptions.value = res.data.map((item: any) => ({
        value: item.roleId,
        label: item.roleValue
    }))
}

// 获取用户角色列表
const getUserRoleList = async () => {
    const res = await getUserRoles()
    if (res.code === 20000) {
        userRoleList.value = res.data.map((item: any) => ({
            userId: item.userId,
            roleIds: item.roleIds.split(',')
        }))
    } else {
        message.error(res.message)
    }
}

// 获取所有企业
const getEnterpriseList = async () => {
    const res = await getEnterprises()
    if (res.code === 20000) {
        enterpriseOptions.value = res.data.map((item: any) => ({
            value: item.code,
            label: item.name
        }))
    } else {
        message.error(res.message)
    }
}

const editingUser = ref({})

const handleSearch = async () => {
    loading.value = true
    await getUserRoleList()
    await getUserRoleOptions()
    await getEnterpriseList()
    getUsers(searchMap.value)
        .then(res => {
            if (res.code === 20000) {
                tableData.value = res.data.records.map((item: any) => {
                    const userRole = userRoleList.value.find((userRole: any) => userRole.userId === item.id)
                    return {
                        ...item,
                        roleIds: userRole?.roleIds || []
                    }
                })
                pagination.total = res.data.total
                pagination.current = res.data.current
                pagination.pageSize = res.data.size
            } else {
                message.error(res.message)
            }
        })
        .finally(() => {
            loading.value = false
        })
}

const loading = ref(false)

const columns = [
    {
        title: '用户名',
        dataIndex: 'userName',
        sorter: true
    },
    {
        title: '密码',
        dataIndex: 'password'
    },
    {
        title: '当前在线人数',
        dataIndex: 'currentCount'
    },
    {
        title: '最大在线人数',
        dataIndex: 'maxCount'
    },
    {
        title: '是否消息管理者',
        dataIndex: 'msgManager'
    },
    {
        title: '创建时间',
        dataIndex: 'createDate',
        customRender: ({ text }: { text: string | null }) => {
            if (!text) return ''
            const date = new Date(text)
            return date.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })
        }
    },
    {
        title: '操作',
        dataIndex: 'operation'
    }
]

const handleTableChange = (pagination: any) => {
    searchMap.value.page = pagination.current
    searchMap.value.pageSize = pagination.pageSize
    handleSearch()
}

const handleUserEdit = (record: any) => {
    editingUser.value = record
    open.value = true
}

const handleUserDelete = (record: any) => {
    deleteUserById(record.id).then(res => {
        if (res.code === 20000) {
            message.success('删除成功')
            handleSearch()
        }
    })
}

onMounted(() => {
    handleSearch()
})
</script>

<style scoped lang="scss">
.form-area {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left-section {
        display: flex;
        align-items: center;
    }

    .ant-input-affix-wrapper {
        width: 200px;
    }
}
</style>
