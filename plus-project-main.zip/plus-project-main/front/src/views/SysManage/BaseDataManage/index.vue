<template>
    <a-tabs v-model:activeKey="activeKey" @change="tabItemSelected">
        <a-tab-pane v-for="item in baseTabs" :key="item.key" :tab="item.tab"></a-tab-pane>
    </a-tabs>
    <keep-alive>
        <component :is="currentComponent" />
    </keep-alive>
</template>

<script setup lang="ts">
import RoleManage from './RoleManage/index.vue'
import AuthorityManage from './AuthorityManage/index.vue'
import EnterpriseManage from './EnterpriseManage/index.vue'

const baseTabs = [
    {
        key: '1',
        tab: '角色管理',
        component: markRaw(RoleManage)
    },
    {
        key: '2',
        tab: '权限路由管理',
        component: markRaw(AuthorityManage)
    },
    {
        key: '3',
        tab: '单位管理',
        component: markRaw(EnterpriseManage)
    }
]

const currentComponent = ref(baseTabs[0].component)
const tabItemSelected = (key: string) => {
    const tab = baseTabs.find(item => item.key === key)
    if (tab) {
        currentComponent.value = tab.component
    }
}

const activeKey = ref('1')
</script>
