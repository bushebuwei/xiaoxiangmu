<template>
    <div class="page-container">
        <div class="form-area">
            <a-button type="primary" @click="open = true">新增</a-button>
        </div>
        <div class="content-area">
            <a-table :columns="columns" :data-source="tableData" :row-key="(record:any) => record.roleId">
                <template #bodyCell="{ column, record }">
                    <template v-if="column.key === 'permissions'">
                        <a-tag v-for="perm in record.permissions" :key="perm.permId">
                            {{ perm.permName }}
                        </a-tag>
                    </template>
                </template>
            </a-table>
        </div>
        <AddOrEditRole v-model:open="open" @success="fetchUserList" />
    </div>
</template>

<script setup lang="ts">
import { getRoleAndPermission } from '@/services/SysAuthorityRolePermission'
import AddOrEditRole from './components/AddOrEditRole.vue'

const open = ref(false)

const columns = [
    {
        title: '角色ID',
        dataIndex: 'roleId',
        key: 'roleId'
    },
    {
        title: '角色名称',
        dataIndex: 'roleName',
        key: 'roleName'
    },
    {
        title: '角色值',
        dataIndex: 'roleValue',
        key: 'roleValue'
    },
    {
        title: '权限列表',
        key: 'permissions'
    }
]

const tableData = ref([])

const fetchUserList = () => {
    getRoleAndPermission().then(res => {
        // 转换数据格式以适应表格显示
        tableData.value = res.data.map((item: any) => ({
            ...item.sysAuthorityRole,
            permissions: item.sysAuthorityPermissionList
        }))
    })
}

onActivated(() => {
    fetchUserList()
})
</script>
