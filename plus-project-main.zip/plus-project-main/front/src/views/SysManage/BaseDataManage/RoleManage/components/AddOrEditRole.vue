<template>
    <a-modal
        :title="props.editData ? '修改角色' : '新增角色'"
        :open="props.open"
        @ok="handleSubmit"
        @cancel="handleCancel"
    >
        <a-form ref="formRef" :model="formState" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-form-item label="角色名称" name="roleName">
                <a-input v-model:value="formState.roleName" placeholder="请输入角色名称" />
            </a-form-item>
            <a-form-item label="角色值" name="roleValue">
                <a-input v-model:value="formState.roleValue" placeholder="请输入角色值" />
            </a-form-item>
            <a-form-item label="权限" name="permission">
                <a-tree-select
                    v-model:value="formState.permissions"
                    :tree-data="treeData"
                    tree-checkable
                    allow-clear
                    :show-checked-strategy="SHOW_PARENT"
                    placeholder="请选择权限"
                    tree-node-filter-prop="label"
                />
            </a-form-item>
        </a-form>
    </a-modal>
</template>

<script setup lang="ts">
import { getPermissions } from '@/services/SysAuthorityPermission'
import { addRole } from '@/services/sysAuthorityRole'
import { message, type FormInstance } from 'ant-design-vue'
import { TreeSelect } from 'ant-design-vue'

const props = defineProps<{
    open: boolean
    editData?: any
}>()

const emit = defineEmits(['update:open', 'success'])

const formRef = ref<FormInstance>()
const formState = reactive({
    roleName: props.editData?.roleName || '',
    roleValue: props.editData?.roleValue || '',
    permissions: props.editData?.permissions || []
})

const rules = {
    roleName: [{ required: true, message: '请输入角色名称' }],
    roleValue: [{ required: true, message: '请输入角色值' }],
    permissions: [{ required: true, message: '请选择权限' }]
}

const SHOW_PARENT = TreeSelect.SHOW_PARENT

const labelCol = { span: 6 }
const wrapperCol = { span: 16 }

const treeData = ref<any[]>([])

const handleSubmit = () => {
    formRef.value?.validate().then(() => {
        if (props.editData) {
            console.log('编辑角色')
        } else {
            addRole(formState).then(res => {
                emit('success', formState)
            })
        }
        message.success('操作成功')
        handleCancel()
    })
}

const handleCancel = () => {
    formRef.value?.resetFields()
    emit('update:open', false)
}

const fetchPermissionList = async () => {
    try {
        const res = await getPermissions()
        treeData.value = []
        const parentNodes: { [key: string]: any } = {}
        res.data.forEach((item: any) => {
            const parts = item.permValue.split('/')
            if (parts.length === 2) {
                parentNodes[item.permValue] = {
                    label: item.permName,
                    value: item.permValue,
                    children: []
                }
                treeData.value.push(parentNodes[item.permValue])
            } else if (parts.length > 2) {
                const parentValue = `${parts[0]}/${parts[1]}`
                if (parentNodes[parentValue]) {
                    parentNodes[parentValue].children.push({
                        label: item.permName,
                        value: item.permValue
                    })
                }
            }
        })
    } catch (error) {
        message.error('获取权限列表失败')
    }
}

watch(
    () => props.open,
    async newVal => {
        if (newVal) {
            await fetchPermissionList()
        }
    }
)
</script>
