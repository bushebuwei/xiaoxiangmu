<template>
    <div class="page-container">
        <div class="form-area">
            <a-button type="primary" @click="open = true">新增权限</a-button>
        </div>
        <div class="content-area">
            <a-list size="large" bordered :data-source="data" class="scrollable-list">
                <template #renderItem="{ item }">
                    <a-list-item>
                        <a-card class="perm-card" :bordered="false">
                            <template #title>
                                <a-space>
                                    <lock-outlined />
                                    {{ item.permName }}
                                </a-space>
                            </template>
                            <div class="perm-value">
                                <tag-outlined />
                                <span>{{ item.permValue }}</span>
                            </div>
                        </a-card>
                    </a-list-item>
                </template>
            </a-list>
        </div>
        <add-or-edit-authority v-model:open="open" :edit-data="editData" @success="handleSuccess" />
    </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { getPermissions } from '@/services/SysAuthorityPermission'
import { LockOutlined, TagOutlined } from '@ant-design/icons-vue'
import AddOrEditAuthority from './components/AddOrEditAuthority.vue'
import { message } from 'ant-design-vue'

const open = ref(false)
const data = ref([])
const editData = ref(null)

const fetchPermissionList = async () => {
    try {
        const res = await getPermissions()
        data.value = res.data.map((item: any) => ({
            permName: item.permName,
            permValue: item.permValue
        }))
    } catch (error) {
        message.error('获取权限列表失败')
    }
}

const handleSuccess = async () => {
    fetchPermissionList()
}

onActivated(() => {
    fetchPermissionList()
})
</script>

<style scoped>
.page-container {
    height: 100%;
    display: flex;
    flex-direction: column;
}

.content-area {
    flex: 1;
    overflow: hidden;
}

.scrollable-list {
    height: 100%;
    overflow-y: auto;
}

.perm-card {
    width: 100%;
    background-color: #fafafa;
}

/* .perm-card :deep(.ant-card-body) {
    padding: 12px 24px;
} */

.perm-value {
    color: #666;
    display: flex;
    align-items: center;
    gap: 8px;
}
</style>
