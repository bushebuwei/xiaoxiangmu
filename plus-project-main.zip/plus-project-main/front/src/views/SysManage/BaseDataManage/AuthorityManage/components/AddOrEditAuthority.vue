<template>
    <a-modal
        :title="props.editData ? '修改权限' : '新增权限'"
        :open="props.open"
        @ok="handleSubmit"
        @cancel="handleCancel"
    >
        <a-form ref="formRef" :model="formState" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-form-item label="权限名称" name="permName">
                <a-input v-model:value="formState.permName" placeholder="请输入权限名称" />
            </a-form-item>
            <a-form-item label="权限值" name="permValue">
                <a-input v-model:value="formState.permValue" placeholder="请输入权限值" />
            </a-form-item>
        </a-form>
    </a-modal>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { message, type FormInstance } from 'ant-design-vue'
import { addPermission } from '@/services/SysAuthorityPermission'

const props = defineProps<{
    open: boolean
    editData?: any
}>()

const emit = defineEmits(['update:open', 'success'])

const formRef = ref<FormInstance>()
const formState = reactive({
    permName: props.editData?.permName || '',
    permValue: props.editData?.permValue || ''
})

const labelCol = { span: 6 }
const wrapperCol = { span: 16 }

const rules = {
    permName: [{ required: true, message: '请输入权限名称' }],
    permValue: [{ required: true, message: '请输入权限值' }]
}

const handleSubmit = () => {
    formRef.value?.validate().then(() => {
        if (props.editData) {
            console.log(222)
        } else {
            addPermission(formState).then(res => {
                emit('success', formState)
            })
        }
        message.success('操作成功')
        handleCancel()
    })
}

const handleCancel = () => {
    formRef.value?.resetFields()
    emit('update:open', false)
}
</script>
