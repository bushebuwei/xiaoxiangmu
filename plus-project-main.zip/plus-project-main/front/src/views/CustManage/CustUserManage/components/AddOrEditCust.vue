<template>
    <a-modal
        :title="props.editData ? '修改客户' : '新增客户'"
        :open="props.open"
        width="600px"
        @ok="handleSubmit"
        @cancel="emit('close')"
    >
        <a-form ref="formRef" :model="formState" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol">
            <a-form-item label="账号" name="code">
                <a-input v-model:value="formState.code" placeholder="请输入账号" />
            </a-form-item>
            <a-form-item label="客户名称" name="name">
                <a-input v-model:value="formState.name" placeholder="请输入客户名称" />
            </a-form-item>
            <a-form-item label="昵称" name="nickName">
                <a-input v-model:value="formState.nickName" placeholder="请输入昵称" />
            </a-form-item>
            <a-form-item label="性别" name="gender">
                <a-select v-model:value="formState.gender" placeholder="请选择性别">
                    <a-select-option value="M">男</a-select-option>
                    <a-select-option value="F">女</a-select-option>
                </a-select>
            </a-form-item>
            <a-form-item label="企业名称" name="enterprise">
                <a-input v-model:value="formState.enterprise" placeholder="请输入企业名称" />
            </a-form-item>
            <a-form-item label="企业编号" name="enterpriseCode">
                <a-input v-model:value="formState.enterpriseCode" placeholder="请输入企业编号" />
            </a-form-item>
            <a-form-item label="手机号码" name="cellphone">
                <a-input v-model:value="formState.cellphone" placeholder="请输入手机号码" />
            </a-form-item>
            <a-form-item label="企业地址" name="entAddress">
                <a-input v-model:value="formState.entAddress" placeholder="请输入企业地址" />
            </a-form-item>
            <a-form-item label="状态" name="status">
                <a-select v-model:value="formState.status" placeholder="请选择状态">
                    <a-select-option value="1">启用</a-select-option>
                    <a-select-option value="0">禁用</a-select-option>
                </a-select>
            </a-form-item>
        </a-form>
    </a-modal>
</template>

<script setup lang="ts">
import { type FormInstance } from 'ant-design-vue'
import { message } from 'ant-design-vue'
import type { UnwrapRef } from 'vue'
import type { Rule } from 'ant-design-vue/es/form'
import { addCustUser } from '@/services/custInformation'
// TODO: Import your API functions
// import { addCustomer, editCustomer } from '@/services/customer'

defineOptions({
    name: 'AddOrEditCust'
})

const props = defineProps({
    open: Boolean,
    editData: {
        type: Object,
        default: null
    }
})

const emit = defineEmits(['success', 'close'])

// Add layout configuration
const labelCol = { span: 6 }
const wrapperCol = { span: 16 }

interface FormState {
    code: string
    name: string
    nickName: string
    gender: string
    enterprise: string
    enterpriseCode: string
    cellphone: string
    entAddress: string
    status: string
}

// Add initial form state constant
const initialFormState: FormState = {
    code: '',
    name: '',
    nickName: '',
    gender: 'M',
    enterprise: '',
    enterpriseCode: '',
    cellphone: '',
    entAddress: '',
    status: '1'
}

const formRef = ref<FormInstance>()
const formState: UnwrapRef<FormState> = reactive({
    ...initialFormState
})

const rules = {
    code: [{ required: true, message: '请输入账号' }],
    name: [{ required: true, message: '请输入客户名称' }],
    gender: [{ required: true, message: '请选择性别' }],
    enterprise: [{ required: true, message: '请输入企业名称' }],
    enterpriseCode: [{ required: true, message: '请输入企业编号' }],
    cellphone: [{ required: true, message: '请输入手机号码' }],
    status: [{ required: true, message: '请选择状态' }]
}

const handleSubmit = () => {
    formRef.value?.validate().then(async () => {
        try {
            const data = toRaw(formState)
            let res
            if (isEdit.value) {
                console.log('编辑客户', data)
            } else {
                res = await addCustUser(data)
            }
            emit('success')
            message.success('操作成功')
        } catch (error) {
            console.log('error', error)
        }
    })
}

const resetForm = () => {
    formRef.value?.resetFields()
    Object.assign(formState, initialFormState)
}

const isEdit = computed(() => {
    return props.editData && Object.keys(props.editData).length > 0
})

watch(
    () => props.open,
    newVal => {
        if (newVal) {
            if (isEdit.value) {
                Object.assign(formState, props.editData)
            }
        } else {
            resetForm()
        }
    }
)
</script>
