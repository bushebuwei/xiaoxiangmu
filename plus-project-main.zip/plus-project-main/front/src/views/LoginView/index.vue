<template>
    <div class="page login-page">
        <div class="page-inner">
            <div class="page-title">农产品在线管理平台</div>
            <a-form
                :model="formState"
                name="basic"
                :wrapper-col="{ span: 24 }"
                autocomplete="off"
                @finish="onFinish"
                @finishFailed="onFinishFailed"
            >
                <a-form-item
                    label=""
                    name="account"
                    :rules="[{ required: true, message: 'Please input your account!' }]"
                >
                    <a-input v-model:value="formState.account" placeholder="用户名" />
                </a-form-item>

                <a-form-item label="" name="password" :rules="[{ required: true, message: '请输入密码' }]">
                    <a-input-password v-model:value="formState.password" placeholder="密码" />
                </a-form-item>

                <a-form-item name="remember" :wrapper-col="{ span: 24 }">
                    <a-checkbox v-model:checked="formState.remember">记住我？</a-checkbox>
                </a-form-item>

                <a-form-item :wrapper-col="{ span: 24 }">
                    <a-button type="primary" html-type="submit" :loading="loading" block>登录</a-button>
                </a-form-item>
            </a-form>
        </div>
    </div>
</template>
<script lang="ts" setup>
defineOptions({
    name: 'LoginView'
})
import { reactive } from 'vue'
import { useUserStore } from '@/stores'
const userStore = useUserStore()
interface FormState {
    account: string
    password: string
    remember: boolean
}

const loading = ref<boolean>(false)
const formState = reactive<FormState>({
    account: '',
    password: '',
    remember: false
})
const onFinish = async (values: any) => {
    try {
        loading.value = true
        await userStore.userLogin({ ...values })
    } catch (e) {
        loading.value = false
    }
}

const onFinishFailed = (errorInfo: any) => {
    console.log('Failed:', errorInfo)
}
</script>

<style lang="scss" scoped>
.login-page {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    .page-inner {
        width: 480px;
        height: 350px;
        padding: 24px;
        border-radius: 8px;
        background-color: #fff;
        box-shadow: 0 3px 15px rgba(74, 143, 255, 0.32);

        .page-title {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 24px;
            color: #333;
        }
    }
}
</style>
