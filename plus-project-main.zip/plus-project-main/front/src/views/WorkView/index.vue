<template>
    <!-- <AreaCascade :addr-id="addrId" /> -->
    1
</template>

<script lang="ts" setup>
import AreaCascade from '@/components/AreaCascade.vue'
defineOptions({
    name: 'WorkView'
})

const addrId = ref('')
</script>
