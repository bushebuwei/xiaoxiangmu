<template>
    <a-cascader
        class="custom-cascade"
        v-model:value="localAddrId"
        :fieldNames="{ label: 'name', value: 'code' }"
        :options="options"
        placeholder="请选择地址"
    />
</template>

<script lang="ts" setup>
defineOptions({
    name: 'AreaCascade'
})

const props = defineProps<{
    addrId: string[]
}>()

import { ref, watch } from 'vue'
import type { CascaderProps } from 'ant-design-vue'
import areaData from '@/components/AreaData.json'

const options: CascaderProps['options'] = areaData

const emit = defineEmits<{
    (e: 'update:addrId', value: string[]): void
}>()

const localAddrId = ref<string[]>(props.addrId)

watch(
    () => props.addrId,
    newVal => {
        localAddrId.value = newVal
    }
)

watch(
    () => localAddrId.value,
    newVal => {
        emit('update:addrId', newVal)
    }
)
</script>

<style lang="scss" scoped>
.custom-cascade {
    width: auto;
}
</style>
