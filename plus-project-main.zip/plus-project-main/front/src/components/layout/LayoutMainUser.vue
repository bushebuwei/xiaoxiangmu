<script setup lang="ts">
defineOptions({
    name: 'LayoutMainUser'
})

import { LogoutOutlined, CaretDownOutlined, UserOutlined } from '@ant-design/icons-vue'
import { useUserStore } from '@/stores'
import { storeToRefs } from 'pinia'
const userStore = useUserStore()
const { userInfo } = storeToRefs(userStore)
const open = ref<boolean>(false)

const handleLogout = async () => {
    try {
        await userStore.userLogout()
    } catch (e) {
        console.log(e)
    }
}

const handleUserInfo = () => {
    open.value = true
}

const handleOk = (e: MouseEvent) => {
    open.value = false
}
</script>

<template>
    <a-dropdown>
        <div class="menu-item__user">
            <img src="../../assets/images/logo.png" alt="" class="user-avatar" />
            <div class="user-name">{{ userInfo.username }}</div>
            <div class="user-drop-icon">
                <caret-down-outlined />
            </div>
        </div>
        <template #overlay>
            <a-menu>
                <a-menu-item @click="handleUserInfo">
                    <user-outlined />
                    个人信息
                </a-menu-item>
                <a-menu-item @click="handleLogout">
                    <logout-outlined style="font-size: 14px; margin-right: 4px" />
                    退出登录
                </a-menu-item>
            </a-menu>
        </template>
    </a-dropdown>
    <a-modal v-model:open="open" width="700px" title="个人信息" @ok="handleOk">
        <a-descriptions>
            <a-descriptions-item label="用户名">{{ userInfo.userName }}</a-descriptions-item>
            <a-descriptions-item label="电话">1810000000</a-descriptions-item>
            <a-descriptions-item label="权限">{{ userInfo.roles }}</a-descriptions-item>
            <a-descriptions-item label="是否为管理员">是</a-descriptions-item>
            <a-descriptions-item label="地址">中国长沙</a-descriptions-item>
        </a-descriptions>
    </a-modal>
</template>

<style scoped lang="scss">
.menu-item__user {
    width: 100%;
    text-align: center;
    line-height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    cursor: pointer;
    margin-left: 20px;
    .user-avatar {
        width: 40px;
        height: 40px;
        object-fit: contain;
        border-radius: 50%;
        background: #d0d8e4;
    }
    .user-name {
        color: #1a1a1a;
        font-size: 14px;
    }
}
</style>
