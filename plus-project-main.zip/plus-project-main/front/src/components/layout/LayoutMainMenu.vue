<script setup lang="ts">
import type { RouteRecordRaw } from 'vue-router'

// import { MailOutlined, CalendarOutlined, AppstoreOutlined, SettingOutlined } from '@ant-design/icons-vue'
defineOptions({
    name: 'LayoutMainMenu'
})
const route = useRoute()
const router = useRouter()

const selectedKeys = ref<string[]>(['Home'])

const handleGoto = (item: any) => {
    router.push({
        name: item.key
    })
}

watchEffect(() => {
    selectedKeys.value = [route.name as string]
})

const buildMenuTree = (routes: RouteRecordRaw[]) => {
    const result: any[] = []
    const routeMap = new Map()

    // 首先将所有路由按照 name 存储
    routes.forEach(route => {
        if (route.meta?.menu) {
            routeMap.set(route.name, {
                key: route.name,
                label: route.meta.title
            })
        }
    })

    // 构建树形结构
    routes.forEach(route => {
        if (!route.meta?.menu) return

        const path = route.path
        const pathSegments = path.split('/').filter(Boolean)

        if (pathSegments.length > 1) {
            // 查找父路由
            const parentPath = '/' + pathSegments[0]
            const parentRoute = routes.find(r => r.path === parentPath)

            if (parentRoute?.name && routeMap.has(parentRoute.name)) {
                const parentMenu = routeMap.get(parentRoute.name)
                const currentMenu = routeMap.get(route.name)
                if (currentMenu) {
                    if (!parentMenu.children) {
                        parentMenu.children = []
                    }
                    parentMenu.children.push(currentMenu)
                }
            }
        } else {
            result.push(routeMap.get(route.name))
        }
    })

    return result
}

const dynamicMenus = computed(() => {
    const routes = router.getRoutes().filter(route => route.meta?.menu)
    return buildMenuTree(routes)
})
</script>

<template>
    <div class="layout-menu">
        <a-menu
            v-model:selectedKeys="selectedKeys"
            mode="inline"
            :style="{ height: '100%', borderRight: 0 }"
            :items="dynamicMenus"
            @click="handleGoto"
        />
    </div>
</template>

<style lang="scss" scoped>
.layout-menu {
    width: 216px;
    display: flex;
    flex-direction: column;
    flex: 0 0 216px;
    max-width: 216px;
    min-width: 216px;
    flex-shrink: 0;
    height: 100%;
    background: none;
    padding: 0 10px 0 16px;
    overflow-y: auto;
    border-right: 1px solid #e5e6eb;
}
</style>
