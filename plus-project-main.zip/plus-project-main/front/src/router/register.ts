import LayoutMain from '@/components/layout/LayoutMain.vue'
import type { RouteRecordRaw } from 'vue-router'

const registerRouter: RouteRecordRaw[] = [
    {
        path: '/:pathMatch(.*)*',
        component: () => import('@/views/ErrorView/NotFound.vue')
    },
    {
        path: '/SysManage',
        name: 'SysManage',
        component: () => import('@/views/SysManage/index.vue'),
        meta: { title: '系统管理', roles: ['admin'], menu: true },
        children: [
            {
                path: 'SysUserManage',
                name: 'SysUserManage',
                component: () => import('@/views/SysManage/UserManage/index.vue'),
                meta: { title: '系统用户管理', roles: ['admin'], menu: true }
            },
            {
                path: 'BaseDataManage',
                name: 'BaseDataManage',
                component: () => import('@/views/SysManage/BaseDataManage/index.vue'),
                meta: { title: '公共数据管理', roles: ['admin'], menu: true }
            }
        ]
    },
    {
        path: '/CustManage',
        name: 'CustManage',
        component: () => import('@/views/CustManage/index.vue'),
        meta: { title: '客户管理', roles: ['admin', 'cust'], menu: true },
        children: [
            {
                path: 'CustUserManage',
                name: 'CustUserManage',
                component: () => import('@/views/CustManage/CustUserManage/index.vue'),
                meta: { title: '客户用户管理', roles: ['admin', 'cust'], menu: true }
            }
        ]
    },
    {
        path: '/FarmerManage',
        name: 'FarmerManage',
        component: () => import('@/views/FarmerManage/index.vue'),
        meta: { title: '产户管理', roles: ['admin', 'farmer'], menu: true },
        children: [
            {
                path: 'FarmerUserManage',
                name: 'FarmerUserManage',
                component: () => import('@/views/FarmerManage/FarmerUserManage/index.vue'),
                meta: { title: '产户用户管理', roles: ['admin', 'farmer'], menu: true }
            },
            {
                path: 'FarmerProductManage',
                name: 'FarmerProductManage',
                component: () => import('@/views/FarmerManage/FarmerProductManage/index.vue'),
                meta: { title: '产户产品管理', roles: ['admin', 'farmer'], menu: true }
            }
        ]
    },
    {
        path: '/OrderManage',
        name: 'OrderManage',
        component: () => import('@/views/OrderManage/index.vue'),
        meta: { title: '订单管理', roles: ['admin', 'order'], menu: true }
    },
    {
        path: '/SettlementManage',
        name: 'SettlementManage',
        component: () => import('@/views/SettlementManage/index.vue'),
        meta: { title: '结算管理', roles: ['admin', 'settlement'], menu: true },
        children: [
            {
                path: 'ProducerSettleManage',
                name: 'ProducerSettleManage',
                component: () => import('@/views/SettlementManage/ProducerSettleManage/index.vue'),
                meta: { title: '产户结算管理', roles: ['admin', 'settlement'], menu: true }
            }
        ]
    },
    {
        path: '/WorkView',
        name: 'WorkView',
        component: () => import('@/views/WorkView/index.vue'),
        meta: { title: '工作台', roles: ['admin', 'work'], menu: true }
    }
]

export default registerRouter
