import LayoutMain from '@/components/layout/LayoutMain.vue'
import { createRouter, createWebHashHistory, type RouteRecordRaw } from 'vue-router'
import { type RouterOptions } from 'vue-router'
import { useUserStore } from '@/stores'
import registerRouters from './register'

// Add this interface to define the meta structure
interface RouteMeta {
    roles?: string[]
    title?: string
}

// 路由集合
const routes: (RouteRecordRaw | any)[] = [
    {
        path: '/',
        name: 'main-layout',
        redirect: { path: '/Home' },
        component: LayoutMain,
        children: [
            {
                path: '/Home',
                name: 'Home',
                component: () => import('@/views/Home/index.vue'),
                meta: { menu: true, title: '首页' }
            },
            {
                path: '/:pathMatch(.*)*',
                name: '404',
                component: () => import('@/views/ErrorView/NotFound.vue')
            }
        ]
    },
    {
        path: '/login',
        name: 'login',
        meta: { title: '登录' },
        component: () => import('@/views/LoginView/index.vue')
    }
]

function filterRoutes(routes: RouteRecordRaw[], roles: string[]) {
    return routes.filter(route => {
        if (route.meta && (route.meta as RouteMeta).roles) {
            return roles.some(role => (route.meta as RouteMeta).roles?.includes(role))
        }
        return false
    })
}

const router = createRouter({
    history: createWebHashHistory(import.meta.env.BASE_URL),
    routes: [...routes]
} as RouterOptions)

router.beforeEach(async (to, from, next) => {
    const userStore = useUserStore()
    if (to.path === '/login') {
        // 重置路由到初始状态
        router.getRoutes().forEach(route => {
            if (
                route.name !== 'login' &&
                route.name !== 'main-layout' &&
                route.name !== 'Home' &&
                route.name !== '404'
            ) {
                router.removeRoute(route.name as string)
            }
        })
        userStore.isRoutesLoaded = false
        next()
        return
    }

    const userInfo = localStorage.getItem('userInfo')
    if (!userInfo) {
        next('/login')
        return
    }

    if (!userStore.isRoutesLoaded) {
        const accessRoutes = filterRoutes(registerRouters, userStore.userInfo.roles)
        accessRoutes.forEach(route => {
            router.addRoute('main-layout', route)
        })
        userStore.isRoutesLoaded = true
        return next({ path: to.fullPath, replace: true })
    }

    if (to.name === '404' && router.hasRoute(to.fullPath.slice(1))) {
        return next({ path: to.fullPath, replace: true })
    }

    next()
})

export default router
