# v-loading

## Usage

```vue
<div v-loading.fullscreen="loading" loading-tip="加载中">
    <div>内容</div>
</div>
```

## Modifiers

| 参数       | 说明     | 可选值 | 默认值 |
| ---------- | -------- | ------ | ------ |
| fullscreen | 是否全屏 | 可选   |        |

## Attributes

用于设置 Loading 组件的参数，通过 HTML 属性传递，参数名为 `loading-` 开头，如 `loading-tip`。

具体参数同渲染的 [spin](https://next.antdv.com/components/spin-cn) 组件

| 参数 | 说明 | 类型   | 可选值 | 默认值 |
| ---- | ---- | ------ | ------ | ------ |
| tip  | 文本 | string | 可选   |        |
