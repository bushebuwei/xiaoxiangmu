import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/farmerProduct'

export const getFarmerProducts = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getFarmerProducts`,
        method: 'post',
        data
    })
}

export const getFarmerProductNames = (): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getFarmerProductNames`,
        method: 'get'
    })
}
