import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/pubEnterprise'
/**
 * 获取所有的企业单位
 */
export const getEnterprises = (): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getEnterprises`,
        method: 'get'
    })
}
