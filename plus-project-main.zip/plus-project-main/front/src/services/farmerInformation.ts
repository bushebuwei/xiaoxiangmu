import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/farmerInformation'

export const getFarmerInformations = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getFarmerInformations`,
        method: 'post',
        data
    })
}
