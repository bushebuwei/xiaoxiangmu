import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/orderHead'

export const getOrderHeads = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getOrderHeads`,
        method: 'post',
        data
    })
}

export const addOrder = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/addOrder`,
        method: 'post',
        data
    })
}
