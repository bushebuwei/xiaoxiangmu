import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/orderDetail'

export const getOrderDetailByOrderId = (orderId: string): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getOrderDetailByOrderId`,
        method: 'post',
        params: {
            orderId
        }
    })
}
