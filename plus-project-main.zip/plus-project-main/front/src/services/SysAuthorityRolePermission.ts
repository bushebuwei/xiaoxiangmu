import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/sysAuthorityRolePermission'
/**
 * 获取所有的权限
 */
export const getRoleAndPermission = (): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getRoleAndPermission`,
        method: 'get'
    })
}
