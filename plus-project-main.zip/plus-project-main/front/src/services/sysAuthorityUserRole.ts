import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/sysAuthorityUserRole'
/**
 * 获取所有的权限角色
 */
export const getUserRoles = (): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getUserRoles`,
        method: 'get'
    })
}
