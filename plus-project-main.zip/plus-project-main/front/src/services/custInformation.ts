import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/custInformation'

export const getCustUsers = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getCustUsers`,
        method: 'post',
        data
    })
}

export const addCustUser = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/addCust`,
        method: 'post',
        data
    })
}

export const getCustNames = (): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getCustNames`,
        method: 'get'
    })
}
