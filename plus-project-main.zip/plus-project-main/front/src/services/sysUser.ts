import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/user'
/**
 * 登录
 */
export const login = (data: { username: string; password: string; roleType: string }): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/login`,
        method: 'post',
        data
    })
}

/**
 * 添加用户
 * @param data
 * @returns
 */

export const addUser = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/addUser`,
        method: 'post',
        data
    })
}

/**
 * 编辑用户
 * @param data
 * @returns
 */
export const editUser = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/editUser`,
        method: 'post',
        data
    })
}

/**
 * 删除用户
 * @param data
 * @returns
 */
export const deleteUserById = (id: string): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/deleteUserById/${id}`,
        method: 'post'
    })
}

/**
 * 查询用户列表
 * @param data
 */
export const getUsers = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getUsers`,
        method: 'post',
        data
    })
}

/**
 * 退出登录
 */
export const logout = () => {
    return request({
        url: '/v1/login',
        method: 'post'
    })
}
