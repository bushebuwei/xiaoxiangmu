import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/sysAuthorityRole'
/**
 * 获取所有的权限角色
 */
export const getRoles = (): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getRoles`,
        method: 'get'
    })
}

export const addRole = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/addRole`,
        method: 'post',
        data
    })
}
