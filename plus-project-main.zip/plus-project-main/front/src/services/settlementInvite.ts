import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/settlementInvite'

export const startSettlement = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/startSettlement`,
        method: 'post',
        data
    })
}

export const getSettlementInvites = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getSettlementInvites`,
        method: 'post',
        data
    })
}
