import { type ApiPromise, request } from '@/libs'

const BASE_URL = '/sysAuthorityPermission'
/**
 * 获取所有的权限
 */
export const getPermissions = (): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/getPermissions`,
        method: 'get'
    })
}

export const addPermission = (data: any): ApiPromise<any> => {
    return request({
        url: `${BASE_URL}/addPermission`,
        method: 'post',
        data
    })
}
